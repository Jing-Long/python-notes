"""COMP6730 question 8.

This should be completed individually.

Author: <u5869920>
Date: <2018/10/21>
"""
import matplotlib.pyplot as plt
import assignment as assign
def plot_fire_spread(initial_bushfire, vegetation_type, vegetation_density, wind_speed):
    '''
    This function uses the data from stochastic simulation of bushfire to plot 
    the number of cells on fire over the simulation step for each vegetation type 
    until the simulation has covered most of the area of the map and the number 
    of cells on fire does not increase any more for any vegetation types.
    ---------
    << Parameter >>
    initial_bushfire: (list of lists of float elements) Map of the initial bushfire
    vegetation_type: (list of lists of str elements) Map of different vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation density at each cell
    wind_speed: (list of lists of float elements) Map of wind speeds at each cell 
    << Retrurns >>
    None
    '''
    # creat a dictionary for vegetation type and count list which will include the number of 
    # on fire cells for each step. 
    type_count_list={'Grassland':[],'Arboretum': [],'Open Forest': [],
                    'Open Woodland': [], 'Urban Vegetation': [], 'Forest': [],
                    'Woodland':[],'Golf Course':[],  'Shrubland':[],'Pine Forest':[],
                    'Vineyard':[]}
    for step in range(2*max(len(initial_bushfire),len(initial_bushfire[0]))): # the maximum step that needs to simulate, which can cover the whole map
        
        bushfire_map=assign.simulate_bushfire_stochastic(initial_bushfire, step,
    vegetation_type, vegetation_density, wind_speed) # load bushfire map from stochastic simulation
        
        count=0 # count the number of vegetation types that have the same cells on fire between two steps
        
        type_and_count={} # record vegetation type and number of cells on fire after each step
        for i in range(len(bushfire_map)):
            for j in range(len(bushfire_map[i])):
                if bushfire_map[i][j] ==True: 
                   if vegetation_type[i][j] in type_and_count:
                      type_and_count[vegetation_type[i][j]] += 1
                   else:
                      type_and_count[vegetation_type[i][j]]=1
                      
        # put the count of on fire cells number for this step into the count list
        for item in type_and_count:
            if item in type_count_list:
                type_count_list[item].append(type_and_count[item])
            else:
                type_count_list[item]=[]
                type_count_list[item].append(type_and_count[item])
        for item in type_count_list:
            if sum(type_count_list[item])==0:   # if there is no cells on fire for which vegetation type,
                type_count_list[item].append(0) # just append 0 for this step
        if step>=max(len(initial_bushfire),len(initial_bushfire[0])): # at least the simulation has covered most of the map
            for item in type_count_list:
                if type_count_list[item][step]==type_count_list[item][step-1]: #compare the number of on fire cells between two steps
                    count+=1

        if count==len(type_count_list): # if all vegetation types have the same number of on fire cells between two steps, break the loop
            steps=step
            break
        
    ax = plt.subplot(111)
    for item in type_count_list:
        if sum(type_count_list[item])!=0:
            x=range(1,steps+2) # the step range for the plot
            plt.scatter(x, type_count_list[item],marker='.')
            plt.plot(x, type_count_list[item],label=item)
    ax.legend(frameon=False,loc='center left', bbox_to_anchor=(1, 0.5))
    plt.xlabel('steps')
    plt.ylabel('Number of cells on fire')
    plt.savefig('/students/u5869920/Desktop/south',format='pdf',bbox_inches='tight')
            
            


if __name__ == '__main__':
    # If you want something to happen when you run this file,
    # put the code in this `if` block.
    pass
