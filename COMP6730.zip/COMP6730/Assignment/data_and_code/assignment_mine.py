"""COMP1730/6730 assignment S2 2018.

Coauthors: <u5869920>, <University ID>, <University ID>
Date: <2018/10/04>
"""

from visualise import show_vegetation_type
from visualise import show_vegetation_density
from visualise import show_wind_speed
from visualise import show_bushfire
from visualise import show_fire_risk

import csv
import math
import random
import matplotlib.pyplot as plt
# The following functions must return the data in the form of a
# list of lists; the choice of data type to represent the value
# in each cell, for each file type, is up to you.

def load_vegetation_type(filename):
    with open(filename) as file:
        reader=csv.reader(file)
        data=[row for row in reader]
        count=0
        for i in range(len(data)):
            for j in range(len(data[i])):
                if data[i][j] == '':
                    count+=1
    return data
        
def load_vegetation_density(filename):
    with open(filename) as file:
        reader=csv.reader(file)
        data=[row for row in reader]
        count=0
        for i in range(len(data)):
            for j in range(len(data[0])):
                if data[i][j]=='':
                    data[i][j]=0
                    count+=1
                else:
                    data[i][j]=float(data[i][j])
    return data

def load_wind_speed(filename):
    with open(filename) as file:
        reader=csv.reader(file)
        data=[row for row in reader]
        count=0
        for i in range(len(data)):
            for j in range(len(data[0])):
                if data[i][j]=='':
                    data[i][j]=0
                    count+=1
                else:
                    data[i][j]=float(data[i][j])
    return data

def load_bushfire(filename):
    with open(filename) as file:
        reader=csv.reader(file)
        data=[row for row in reader]
        count=0
        for i in range(len(data)):
            for j in range(len(data[0])):
                if data[i][j]=='':
                    data[i][j]=-1
                    count+=1
                else:
                    data[i][j]=int(data[i][j])
    return data


# The argument to this function is a wind speed map, in the
# form of a list of lists; it is the same data structure that
# is returned by your implementation of the load_wind_speed
# function.

def highest_wind_speed(wind_speed):
    return max([max(sublist) for sublist in wind_speed])


# The argument to this function is a vegetation type map, in the
# form of a list of lists; it is the same data structure that
# is returned by your implementation of the load_vegetation_type
# function.

def count_cells(vegetation_type):
    type_and_count={}
    for row in vegetation_type:
        for vege in row:
            if vege=='':
                continue
            else:
                if vege in type_and_count:
                   type_and_count[vege]=type_and_count[vege]+1
                else:
                   type_and_count[vege]=1
    #print(type_and_count)
    for item in type_and_count:
        print(item+':', type_and_count[item])


# The arguments to this function are a vegetation type map and
# a vegetation density map, both in the form of a list of lists.
# They are the same data structure that is returned by your
# implementations of the load_vegetation_type and load_vegetation_density
# functions, respectively.

def count_area(vegetation_type, vegetation_density):
    type_and_density={}
    for i in range(len(vegetation_type)):
        for j in range(len(vegetation_type[0])):
            if vegetation_type[i][j]=='':
                continue
            else:
                if vegetation_type[i][j] in type_and_density:
                    type_and_density[vegetation_type[i][j]]=type_and_density[vegetation_type[i][j]]+vegetation_density[i][j]*10000
                else:
                    type_and_density[vegetation_type[i][j]]=vegetation_density[i][j]*10000
    for item in type_and_density:
        print(item+':',"%.2f"%type_and_density[item],'sq m')


# The arguments to this function are:
# x and y - integers, representing a position in the grid;
# vegetation_type - a vegetation type map (as returned by your
#   implementation of the load_vegetation_type function);
# vegetation_density - a vegetation density map (as returned by
#   your implementation of the load_vegetation_density function);
# wind_speed - a wind speed map (as returned by your implementation
#   of the load_wind_speed function).
def fire_risk_factor(x,y,vegetation_density,vegetation_type):
    if vegetation_type[x][y]=='Shrubland' or vegetation_type[x][y]=='Pine Forest':
        a=0.2
    elif vegetation_type[x][y]=='Arboretum':
        a=0.1
    elif vegetation_type[x][y]=='Urban Vegetation' or vegetation_type[x][y]=='Golf Course':
        a=0.05
    else:
        a=0
    return math.sqrt(a+vegetation_density[x][y])
    
def fire_risk(x, y, vegetation_type, vegetation_density, wind_speed):
    n=math.floor(wind_speed[x][y])
    row_len=len(vegetation_density)
    col_len=len(vegetation_density[0])    
    if x-n<0:
        xleft=0
    else:
        xleft=x-n+1
    if x+n>row_len:
        xright=row_len
    else:
        xright=x+n
    if y-n<0:
        yleft=0
    else:
        yleft=y-n+1   
    if y+n>col_len:
        yright=col_len
    else:
        yright=y+n

    all_fire_risk=0
    for i in range(xleft,xright):
        for j in range(yleft,yright):
            all_fire_risk+=fire_risk_factor(i,j,vegetation_density,vegetation_type)
    return all_fire_risk
#show_fire_risk(fire_risk, vegetation_type, vegetation_density, wind_speed)
#plt.savefig('anu_fire_risk.pdf',bbox_inches='tight')
# The arguments to this function are an initial bushfile map (a list
# of lists, as returned by your implementation of the load_bushfire
# function), a vegetation type map (as returned by your implementation
# of the load_vegetation_type function), a vegetation density map (as
# returned by your implementation of load_vegetation_density) and a
# positive integer, representing the number of steps to simulate.
def burn_it(x,y,bushfire_map):
    if x<0 or y<0:
        return False
    elif x>=len(bushfire_map) or y>=len(bushfire_map[0]):
        return False
    elif bushfire_map[x][y]==None:
        return None
    else:
        return True    
            
def simulate_bushfire(initial_bushfire, vegetation_type, vegetation_density, steps):
    bushfire_map=initial_bushfire.copy()
    for i in range(len(initial_bushfire)):
        for j in range(len(initial_bushfire[0])):
            if bushfire_map[i][j]==1:
                bushfire_map[i][j]=True
            elif bushfire_map[i][j]==0:
                bushfire_map[i][j]=False
            else:
                bushfire_map[i][j]=None
    #print(bushfire_map)
    for k in range(steps):
        for i in range(len(bushfire_map)):
            for j in range(len(bushfire_map[0])):
                if bushfire_map[i][j]==True:
                    for x in range(i-1,i+2):
                        for y in range(j-1,j+2):
                            if burn_it(x,y,bushfire_map)==True:
                                bushfire_map[x][y]=True                   
    return bushfire_map
            
#show_bushfire(simulate_bushfire(initial_bushfire, vegetation_type, vegetation_density, steps))

# The arguments to this function are two bushfile maps (each a list
# of lists, i.e., same format as returned by your implementation of
# the load_bushfire function).
bushfire_a=load_bushfire("/students/u5869920/Desktop/data_and_code/data/anu/2003_bushfire.csv")
bushfire_b=load_bushfire("/students/u5869920/Desktop/data_and_code/data/anu/initial_2003_bushfire.csv")
def compare_bushfires(bushfire_a, bushfire_b):
    count_cells=0
    count_same_cells=0
    for i in range(len(bushfire_a)):
        for j in range(len(bushfire_a[0])):
            if bushfire_a[i][j]==-1:
                continue
            elif bushfire_a[i][j]==bushfire_b[i][j]:
                count_same_cells+=1
                count_cells+=1
            else:
                count_cells+=1
    percentage=count_same_cells/count_cells
    print(count_cells,count_same_cells)
    return percentage

# The arguments to this function are:
# initial_bushfire - an initial bushfile map (a list of lists, same
#   as returned by your implementation of the load_bushfire function);
# steps - a positive integer, the number of steps to simulate;
# vegetation_type - a vegetation type map (as returned by your
#   implementation of the load_vegetation_type function);
# vegetation_density - a vegetation density map (as returned by
#   your implementation of the load_vegetation_density function);
# wind_speed - a wind speed map (as returned by your implementation
#   of the load_wind_speed function).

def simulate_bushfire_stochastic(
        initial_bushfire, steps,
        vegetation_type, vegetation_density,
        wind_speed):
    bushfire_map = initial_bushfire.copy()
    inc = 2
    for k in range(steps):
        for i in range(len(bushfire_map)):
            for j in range(len(bushfire_map[0])):
                if 0< bushfire_map[i][j] < inc:
                    for x in range(i-1, i+2):
                        for y in range(j-1, j+2):
                            if burn_it(x,y,bushfire_map)==True and random.random()*fire_risk(x, y, vegetation_type, vegetation_density, wind_speed)>20:
                                bushfire_map[x][y] = inc    
        inc+=1
    
    for l in range(len(bushfire_map)):
        for m in range(len(bushfire_map[0])):
            if bushfire_map[l][m] > 0:
                   bushfire_map[l][m]=True
            elif bushfire_map[l][m]==0:
                bushfire_map[l][m]=False
            else:
                bushfire_map[l][m]=None
    show_bushfire(bushfire_map)
    return bushfire_map
#show_bushfire(simulate_bushfire_stochastic(initial_bushfire, 10,vegetation_type, vegetation_density,wind_speed))   


if __name__ == '__main__':
    # If you want something to happen when you run this file,
    # put the code in this `if` block.
    vegetation_density=load_vegetation_density("/students/u5869920/Desktop/data_and_code/data/anu/vegetation_density.csv")
    vegetation_type=load_vegetation_type("/students/u5869920/Desktop/data_and_code/data/anu/vegetation_type.csv")
    wind_speed=load_wind_speed("/students/u5869920/Desktop/data_and_code/data/anu/wind.csv")
    initial_bushfire=load_bushfire("/students/u5869920/Desktop/data_and_code/data/anu/initial_2003_bushfire.csv")
