"""COMP1730/6730 assignment S2 2018.

Coauthors: <u5869920>, <u6609679>
Date: <2018/10/04>
"""

from visualise import show_vegetation_type
from visualise import show_vegetation_density
from visualise import show_wind_speed
from visualise import show_bushfire
from visualise import show_fire_risk

import csv
import math
import random


def load_vegetation_type(filename):
    '''
    Reads a  comma separated values (csv) file 
    and returns the data as a list of lists.
    Blank value  is read as an empty string ''.
    --------
    << Parameters >>
    filename : (str) Filename or path of the csv file to be read

    << Returns >>
    data : (list of lists of str elements) CSV data
    '''
    with open(filename) as file:
        reader = csv.reader(file)
        data = [row for row in reader]
    return data
        
def load_vegetation_density(filename):
    '''
    Reads a  comma separated values (csv) file 
    and returns the data as a list of lists.
    Blank value is read as 0.0 .
    --------
    << Parameters >>
    filename : (str) Filename or path of the csv file to be read

    << Returns >>
    data : (list of lists of float elements) CSV data
    '''
    with open(filename) as file:
        reader = csv.reader(file)
        data = [row for row in reader]
        for i in range(len(data)):
            for j in range(len(data[i])):
                if data[i][j] == '':
                    data[i][j] = 0
                else:
                    data[i][j] = float(data[i][j])
    return data

def load_wind_speed(filename):
    '''
    Reads a comma separated values (csv) file 
    and returns the data as a list of lists.
    Blank value is read as 0.0
    --------
    << Parameters >>
    filename : (str) Filename or path of the csv file to be read

    << Returns >>
    data : (list of lists of float elements) CSV data
    '''
    with open(filename) as file:
        reader = csv.reader(file)
        data = [row for row in reader]
        for i in range(len(data)):
            for j in range(len(data[i])):
                if data[i][j] == '':
                    data[i][j] = 0
                else:
                    data[i][j] = float(data[i][j])
    return data

def load_bushfire(filename):
    '''
    Reads a comma separated values (csv) file 
    and returns the data as a list of lists.
    Blank value is read as -1 .
    --------
    << Parameters >>
    filename : (str) Filename or path of the csv file to be read

    << Returns >>
    data : (list of lists of int elements) CSV data
    '''
    with open(filename) as file:
        reader = csv.reader(file)
        data = [row for row in reader]
        for i in range(len(data)):
            for j in range(len(data[i])):
                if data[i][j] == '':
                    data[i][j] = -1
                else:
                    data[i][j] = int(data[i][j])
    return data


# The argument to this function is a wind speed map, in the
# form of a list of lists; it is the same data structure that
# is returned by your implementation of the load_wind_speed
# function.

def highest_wind_speed(wind_speed):
    '''
    Returns the highest wind speed in the wind_speed map.
    --------
    << Parameters >>
    wind_speed: (list of lists of float elements) Map of wind speeds
    
    << Returns >>
    out : (float) Maximum wind speed
    '''
    return max([max(sublist) for sublist in wind_speed])


# The argument to this function is a vegetation type map, in the
# form of a list of lists; it is the same data structure that
# is returned by your implementation of the load_vegetation_type
# function.

def count_cells(vegetation_type):
    '''
    Prints the number of cells covered by each vegetation type.
    ---------
    << Parameter >>
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types

    << Retrurns >>
    No return statements: (NoneType)
    '''

    type_and_count = {}
    for row in vegetation_type:
        for vege in row:
            if vege=='':
                continue
            else:
                if vege in type_and_count:
                   type_and_count[vege] += 1
                else:
                   type_and_count[vege] = 1

    for item in type_and_count:
        print(item+':', type_and_count[item])
    


# The arguments to this function are a vegetation type map and
# a vegetation density map, both in the form of a list of lists.
# They are the same data structure that is returned by your
# implementations of the load_vegetation_type and load_vegetation_density
# functions, respectively.

def count_area(vegetation_type, vegetation_density):
    '''
    Prints the area covered by each vegetation type.
    ---------
    << Parameter >>
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell

    << Retrurns >>
    No return statements: (NoteType)
    '''

    type_and_density={}
    for i in range(len(vegetation_type)):
        for j in range(len(vegetation_type[i])):
            if vegetation_type[i][j]=='':
                continue
            else:
                if vegetation_type[i][j] in type_and_density:
                    type_and_density[vegetation_type[i][j]] += vegetation_density[i][j]*1e4
                else:
                    type_and_density[vegetation_type[i][j]] = vegetation_density[i][j]*1e4
    for item in type_and_density:
        print(item+':',"%.2f"%type_and_density[item],'sq m')


# The arguments to this function are:
# x and y - integers, representing a position in the grid;
# vegetation_type - a vegetation type map (as returned by your
#   implementation of the load_vegetation_type function);
# vegetation_density - a vegetation density map (as returned by
#   your implementation of the load_vegetation_density function);
# wind_speed - a wind speed map (as returned by your implementation
#   of the load_wind_speed function).
def fire_risk_factor(x, y, vegetation_density, vegetation_type):
    '''
    Returns the risk factor for different vegetation types.
    ---------
    << Parameter >>
    x: (int) Row index
    y: (int) Column index
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell

    << Retrurns >>
    (float) Risk factor
    '''
    if vegetation_type[x][y]=='Shrubland' or vegetation_type[x][y]=='Pine Forest':
        a=0.2
    elif vegetation_type[x][y]=='Arboretum':
        a=0.1
    elif vegetation_type[x][y]=='Urban Vegetation' or vegetation_type[x][y]=='Golf Course':
        a=0.05
    else:
        a=0
    return math.sqrt(a+vegetation_density[x][y])

def beyond_edge(i, j, vegetation_density):
    '''
    Returns True if the index (i, j) is beyond the edge of vegetation density map.
    Else returns False. 
    ---------
    << Parameter >>
    i: (int) Row index
    j: (int) Column index
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell

    << Retrurns >>
    (bool)
    '''
    if i<0 or j<0:
        return True
    elif i>=len(vegetation_density) or j>=len(vegetation_density[0]):
        return True
    else:
        return False
    
def fire_risk(x, y, vegetation_type, vegetation_density, wind_speed):
    '''
    Returns the fire risk for a particular cell.
    ---------
    << Parameter >>
    x: (int) Row index
    y: (int) Column index
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell
    wind_speed: (list of lists of float elements) Map of wind speeds 
                at each cell

    << Retrurns >>
    (float) Fire risk
    '''
    #x_ = y
    #y_ = x
    n = math.floor(wind_speed[y][x])
    risk = 0
    for i in range(y - (n-1), y + n):
        for j in range(x - (n-1), x + n):
            if beyond_edge(i, j, vegetation_density) != True:
                risk += fire_risk_factor(i, j, vegetation_density, vegetation_type)
    return risk


# The arguments to this function are an initial bushfile map (a list
# of lists, as returned by your implementation of the load_bushfire
# function), a vegetation type map (as returned by your implementation
# of the load_vegetation_type function), a vegetation density map (as
# returned by your implementation of load_vegetation_density) and a
# positive integer, representing the number of steps to simulate.
def fire_spread(x, y, bushfire_map):
    '''
    Returns False if the index (x, y) is beyond the edge of vegetation density map.
    And returns True if the cell is not on fire.
    ---------
    << Parameter >>
    x: (int) Row index
    y: (int) Column index
    bushfire_map: (list of lists of float elements) Map of the bushfire

    << Retrurns >>
    (bool)
    '''
    if x<0 or y<0:
        return False
    elif x>=len(bushfire_map) or y>=len(bushfire_map[0]):
        return False
    elif bushfire_map[x][y] == 0:
        return True

def spread_cell(bushfire_map, steps, stochastic, risk):
    '''
    Returns the spread bushfire after 'n' number of steps.
    ---------
    << Parameter >>
    bushfire_map: (list of lists of float elements) Map of the bushfire
    steps: (int) Simulation steps 
    stochastic: (bool) Stochastic simulation (True) or not (False)
    chance: (list of lists of float elements) Map of the probability 
            of each cell catching fire (pass only if stochastic == True, else [])

    << Retrurns >>
    bushfire_map: (list of lists of float elements) Map of the spread bushfire 
    '''
    for l in range(len(bushfire_map)):
            for m in range(len(bushfire_map[l])):
                if bushfire_map[l][m] == True:
                    bushfire_map[l][m]= 1
                elif bushfire_map[l][m] == False:
                    bushfire_map[l][m] = 0
                elif bushfire_map[l][m] == None:
                    bushfire_map[l][m] = -1

    for step in range(steps):
        for i in range(len(bushfire_map)):
            for j in range(len(bushfire_map[i])):
                if bushfire_map[i][j] < step+2 and bushfire_map[i][j] > 0:
                    for x in range(i-1, i+2):
                        for y in range(j-1, j+2):
                            if stochastic == True:
                                if fire_spread(x,y,bushfire_map)==True and risk[x][y]>random.random():
                                    bushfire_map[x][y] = step+2 
                            else:
                                if fire_spread(x,y,bushfire_map)==True:
                                    bushfire_map[x][y] = step+2 
    for l in range(len(bushfire_map)):
            for m in range(len(bushfire_map[l])):
                if bushfire_map[l][m] > 0:
                    bushfire_map[l][m] = True
                elif bushfire_map[l][m] == 0:
                    bushfire_map[l][m] = False
                else:
                    bushfire_map[l][m] = None
    return bushfire_map


def simulate_bushfire(initial_bushfire, vegetation_type, vegetation_density, steps):
    '''
    Returns the spread bushfire after 'n' number of steps.
    ---------
    << Parameter >>
    initial_bushfire: (list of lists of float elements) Map of the initial bushfire
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell
    steps: (int) Simulation steps 

    << Retrurns >>
    bushfire_map: (list of lists of float elements) Map of the spread bushfire 
    '''
    bushfire_map = spread_cell(initial_bushfire, steps, False, [] )

    return bushfire_map

            




# The arguments to this function are two bushfile maps (each a list
# of lists, i.e., same format as returned by your implementation of
# # the load_bushfire function).

def compare_bushfires(bushfire_a, bushfire_b):
    '''
    Returns the percentage of similar cells between two bushfire maps.
    ---------
    << Parameter >>
    bushfire_a: (list of lists of float elements) Map of the initial bushfire
    bushfire_b: (list of lists of float elements) Map of the initial bushfire

    << Retrurns >>
    percentage: (float) Percentage of similar cells
    '''
    same_cells = 0
    total_cells = 0

    for i in range( len(bushfire_a)):
        total_cells += len( bushfire_a[i] ) - bushfire_a[i].count(-1)
        for j in range( len(bushfire_a[i])):
            if bushfire_a[i][j] == bushfire_b[i][j] and bushfire_a[i][j] != -1:
                same_cells += 1
    percentage = (same_cells / total_cells)
    print(same_cells,total_cells)
    return percentage

# The arguments to this function are:
# initial_bushfire - an initial bushfile map (a list of lists, same
#   as returned by your implementation of the load_bushfire function);
# steps - a positive integer, the number of steps to simulate;
# vegetation_type - a vegetation type map (as returned by your
#   implementation of the load_vegetation_type function);
# vegetation_density - a vegetation density map (as returned by
#   your implementation of the load_vegetation_density function);
# wind_speed - a wind speed map (as returned by your implementation
#   of the load_wind_speed function).

def simulate_bushfire_stochastic(initial_bushfire, steps,
    vegetation_type, vegetation_density, 
    wind_speed):
    '''
    Returns the spread bushfire after 'n' number of steps. Stochastic simulation.
    ---------
    << Parameter >>
    initial_bushfire: (list of lists of float elements) Map of the initial bushfire
    steps: (int) Simulation steps 
    vegetation_type: (list of lists of str elements) Map of different 
                    vegetation types
    vegetation_density: (list of lists of float elements) Map of vegetation
                        density at each cell
    wind_speed: (list of lists of float elements) Map of wind speeds 
                at each cell

    << Retrurns >>
    bushfire_map: (list of lists of float elements) Map of the spread bushfire 
    '''
    
    risk = [[] for i in range( len(initial_bushfire) )]
    #chance = [[] for i in range( len(initial_bushfire) )]

    for i in range(len(initial_bushfire)):
        for j in range(len(initial_bushfire[i])):
            risk[i].append(fire_risk(j, i, vegetation_type, vegetation_density, wind_speed))
   
    max_risk = max([max(sublist) for sublist in risk])
    for i in range(len(initial_bushfire)):
        for j in range(len(initial_bushfire[i])):
            risk[i][j] = risk[i][j] / max_risk
    
    bushfire_map = spread_cell(initial_bushfire, steps, True, risk )

    return bushfire_map


if __name__ == '__main__':

    initial_bushfire = load_bushfire("data/anu/initial_2003_bushfire.csv")
    bushfire_2003 = load_bushfire("data/anu/2003_bushfire.csv")
    vegetation_type =  load_vegetation_type("data/anu/vegetation_type.csv")
    vegetation_density = load_vegetation_density("data/anu/vegetation_density.csv")
    wind_speed = load_wind_speed("data/anu/wind.csv")

    # count_cells(vegetation_type)
    # count_area(vegetation_type, vegetation_density)

    #show_fire_risk( fire_risk, vegetation_type, vegetation_density, wind_speed)

    # show_bushfire( simulate_bushfire(
    #     initial_bushfire, vegetation_type, vegetation_density, 10) )

    # show_bushfire( bushfire_2003)

    # step = 0
    # bushfire = simulate_bushfire_stochastic(
    #         initial_bushfire, step,
    #         vegetation_type, vegetation_density,
    #         wind_speed)
    # while compare_bushfires(bushfire_2003, bushfire) < 0.9:
    #     # show_bushfire( bushfire )
    #     step += 1
    #     bushfire = simulate_bushfire_stochastic(
    #         initial_bushfire, step,
    #         vegetation_type, vegetation_density,
    #         wind_speed)
    # print(step)
    # print(compare_bushfires( bushfire_2003, initial_bushfire))
    simulate_bushfire(initial_bushfire, vegetation_type, vegetation_density, 2)
    print(compare_bushfires(bushfire_a, bushfire_b))