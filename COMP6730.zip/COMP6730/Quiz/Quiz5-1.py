# -*- coding: utf-8 -*-
"""
Created on Mon Aug 27 20:13:18 2018

@author: Administrator
"""
#5-1
sentence=[86,101,114,121,32,72,97,114,100,32,69,120,97,109]
string=''
for character in sentence:
    string=string+chr(character)
print(string)

#5-4
def f(s):
    for elem1 in s:
        for elem2 in s[::-1]:
            if elem1 == elem2:
                return elem1
            
print(f('abcbdc'))