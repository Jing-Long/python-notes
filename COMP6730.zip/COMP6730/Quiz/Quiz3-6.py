# -*- coding: utf-8 -*-
"""
Created on Tue Aug 14 17:47:21 2018

@author: u5869920
"""

def mystery(m):
    while m > 1:
        i = 2
        while i < m:
            while m % i == 0:
                m = m // i
            i = i + 1
            print("m=",m)
            print("i=",i)
            print(i<m)
    return i