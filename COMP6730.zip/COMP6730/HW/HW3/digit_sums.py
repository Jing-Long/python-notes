## COMP1730/6730 S2 2018 - Homework 3
# Submission is due 9am, Monday the 27th of August, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li


## Modify the following function definitions so that they compute and
## return the correct answers to the homework problems. (The statement
## "return 1" is just a placeholder: you should of course modify it.)
# I have figured out three ways to sum digits, using %, // and loops.
# But I can only upload one, so I upload this concise one using 
# list comprehensions.

def sum_odd_digits(number):
    '''Return the sum of odd digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_odd=sum([int(character) for character in str(number) if int(character)%2==1])
    # convert the number into a string, then read in each character and decide
    # whether the converted integer from this character is an odd number, if 
    # it is, put it into a list. Finally, sum up the odd numbers in this list.
    return sum_odd

def sum_even_digits(number):
    '''Return the sum of even digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_even=sum([int(character) for character in str(number) if int(character)%2==0])
    # convert the number into a string, then read in each character and decide
    # whether the converted integer from this character is an even number, if 
    # it is, put it into a list. Finally, sum up the even numbers in this list.
    return sum_even

def sum_all_digits(number):
    '''Return the sum of the digits of the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_all=sum([int(character) for character in str(number)])
    # convert the number into a string, then read in each character and put it
    # into a list. Finally, sum up all the numbers in this list.
    return sum_all

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS. You can (and should)
## use docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very beginning
## of the function suite. Everywhere else you should use comments.
