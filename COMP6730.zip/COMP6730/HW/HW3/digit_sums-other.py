## COMP1730/6730 S2 2018 - Homework 3
# Submission is due 9am, Monday the 27th of August, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li


## Modify the following function definitions so that they compute and
## return the correct answers to the homework problems. (The statement
## "return 1" is just a placeholder: you should of course modify it.)

def sum_certain_digits(number, identifier):
    '''Return the sum of certain digits in the number, according to the 
    value of identifier. 
    identifier==0, return sum of even digits;
    identifier==1, return sum of odd digits.'''
    i=0
    sum_of_digits=0
    while i<len(str(number)):
        if int(str(number)[i])%2==identifier:
           sum_of_digits=sum_of_digits+int(str(number)[i])
        i=i+1  
    return sum_of_digits
    
def sum_odd_digits(number):
    '''Return the sum of odd digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_odd=sum_certain_digits(number,1)
    return sum_odd

def sum_even_digits(number):
    '''Return the sum of even digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_even=sum_certain_digits(number,0)
    return sum_even

def sum_all_digits(number):
    '''Return the sum of the digits of the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    i=0
    sum_all=0
    while i<len(str(number)):
          sum_all=sum_all+int(str(number)[i])
          i=i+1  
    return sum_all

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS. You can (and should)
## use docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very beginning
## of the function suite. Everywhere else you should use comments.
