## COMP1730/6730 S2 2018 - Homework 3
# Submission is due 9am, Monday the 27th of August, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li


## Modify the following function definitions so that they compute and
## return the correct answers to the homework problems. (The statement
## "return 1" is just a placeholder: you should of course modify it.)

def sum_odd_digits(number):
    '''Return the sum of odd digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_odd=0
    while number>0:
          digit=number%10
          if digit%2!=0:
             sum_odd=sum_odd+digit
          number=number//10
    return sum_odd

def sum_even_digits(number):
    '''Return the sum of even digits in the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_even=0
    while number>0:
          digit=number%10
          if digit%2==0:
             sum_even=sum_even+digit
          number=number//10
    return sum_even

def sum_all_digits(number):
    '''Return the sum of the digits of the number (in base 10).
    Assumption: the number is a non-negtive integer.'''
    sum_all=0
    while number>0:
          digit=number%10
          sum_all=sum_all+digit
          number=number//10
    return sum_all

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS. You can (and should)
## use docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very beginning
## of the function suite. Everywhere else you should use comments.
