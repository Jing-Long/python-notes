## COMP1730/6730 S1 2018 - Homework 2
# Submission is due 9am, Monday the 13th of August, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li

## Modify the following function definition so that it computes and
## returns the n:th number in the sum of squares sequence. 
## (The statement "return 1" is just a placeholder: you should replace it.)


def sum_of_squares(n):
    '''Return the n:th number in the square pyramidal number sequence. n is a non-negative integer'''
    S_n=n*(n+1)*(2*n+1)/6
    return int(S_n)

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS.
