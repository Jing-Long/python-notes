## COMP1730/6730 S2 2018 - Homework 4
# Submission is due 9am, Monday the 17th of September, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li

## Implement the function max_increase below.
## (The statement "pass" is just a placeholder that does nothing: you
## should replace it.)
## You can define other functions if it helps you decompose the problem
## and write a better organised and/or more readable solution.
def is_decreasing(seq):
    '''Returns True if seq is a decreasing sequence else returns False.'''
    i=0
    while i < len(seq):
        j=i+1
        while j < len(seq):
            if seq[i]>seq[j]: # compare the i-th element with elements after it
                j=j+1
            else:
                return False # returns False if any elements after i-th is bigger
        i=i+1
    # only all elements after i-th element are smaller than i can come to this   
    # return, which means seq is a decreasing sequence.    
    return True
    
                

def max_increase(seq):
    '''Returns the maximum increase number from one element in the sequence 
    to an element at a higher index. If the sequence is decreasing or contains
    fewer than 2 elements, returns 0. Assumption: seq is a sequence and its
    elements are integer or decimal numbers.'''
    maximum_increase=0
    # returns 0 when seq contains fewer than 2 elements 
    # or it is a decreasing sequence
    # if the sequence is decreasing, the maximum_increase will keep as 0, so 
    # the return of this function will be 0 at the end. is_decreasing(seq) function
    # is not necessarily to be writen explicitly here.
    if len(seq)<2:# or is_decreasing(seq)==True: 
        return 0
    else:
        for i in range(len(seq)):
            for j in range(i+1,len(seq)):
                if seq[j]-seq[i]>maximum_increase:
                    maximum_increase=seq[j]-seq[i]
        return maximum_increase

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS.