## COMP1730/6730 S2 2018 - Homework 5
# Submission is due 9am, Monday the 1st of October, 2018.

## YOUR ANU ID: u5869920
## YOUR NAME: Jing Li

## Implement the function interpolate below.
## (The statement "pass" is just a placeholder that does nothing: you
## should replace it.)
## You can define other functions if it helps you decompose the problem
## and write a better organised and/or more readable solution.

def interpolate(x, y, x_test):
    '''Returns the linear interpolation result of function f at point x_test.
    Both x and y are sequences with the same length, their elements are numbers.
    The x sequence contains the points where the function has been sampled, and
    the y sequence contains the function value at the corresponding point. In
    other words, y[i]=f(x[i]). Values in x are ordered in increasing order, and
    they are unique. x_test is a number and min(x) <= x_test <= max(x).'''
    for i in range(len(x)):
        if x_test == x[i]: # If x_test is equal to a value in the sequence x,
            return y[i] # returns the corresponding function value from y.
        elif x[i] < x_test < x[i+1]: # even though index i+1 can be out of 
            # range when i==len(x)-1, but the maximum allowd value of x_test is
            # x[len(x)-1], if x_test==x[len(x)-1], the above branching will 
            # return y[len(x)-1]. So as long as min(x)<=x_test<=max(x), this 
            # index will not incur an error.
            slope=(y[i+1]-y[i])/(x[i+1]-x[i]) # slope of the interpolation line
            intersect=y[i]-slope*x[i] # y intersect of the interpolation line
            y_test=slope*x_test+intersect # linear interpolation result
            return y_test

## REMEMBER THAT THIS FILE (WHEN YOU SUBMIT IT) MUST NOT CONTAIN ANYTHING
## OTHER THAN YOUR FUNCTION DEFINITION AND COMMENTS. You can (and should)
## use docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very beginning
## of the function suite. Everywhere else you should use comments.
