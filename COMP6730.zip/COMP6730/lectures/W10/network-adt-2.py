
## Neighbour-set implementation of ADT network.

def create_network(n_nodes):
    '''Returns a new network with n_nodes nodes, but no links.'''
    return { i : set() for i in range(n_nodes) }

def add_node(network):
    '''Add a new node to network. Returns the index of the new node.'''
    ## TODO
    pass

def remove_node(a, network):
    '''Remove node a from the network. This renumbers all nodes with
    index > a to their index - 1.'''
    ## TODO
    pass

def add_link(a, b, network):
    '''Add a link between nodes a and b in network. Does nothing if
    the link already exists.'''
    assert 0 <= a < n_nodes(network), "index " + str(a) + " out of range"
    assert 0 <= b < n_nodes(network), "index " + str(b) + " out of range"
    network[a] = network[a] | { b }
    network[b] = network[b] | { a }

def remove_link(a, b, network):
    '''Remove the link between nodes a and b from the network. Does
    nothing if no such link exists.'''
    assert 0 <= a < n_nodes(network), "index " + str(a) + " out of range"
    assert 0 <= b < n_nodes(network), "index " + str(b) + " out of range"
    network[a] = network[a] - { b }
    network[b] = network[b] - { a }

def n_nodes(network):
    '''Returns the number of nodes in the network.'''
    return len(network)

def connected(a, b, network):
    '''Is there a link between nodes a and b in the network? Returns
    True or False.'''
    assert 0 <= a < n_nodes(network), "index " + str(a) + " out of range"
    assert 0 <= b < n_nodes(network), "index " + str(b) + " out of range"
    return b in network[a]

def neighbours(a, network):
    '''Returns the set of neighbours of node a.'''
    return network[a]


## Algorithm to compute connected components.
## There are several algorithms that can be used for this problem.
## Here, we will implement one based on breadth-first search (a.k.a.
## Dijkstra's algorithm).

def components(network):
    '''Computes the connected components of the network.'''
    comps = [] # list of components (sets of nodes)
    nodes_so_far = set() # set of all nodes in components found so far
    next_node = 0
    while next_node < n_nodes(network):
        if next_node not in nodes_so_far:
            new_comp = find_component(next_node, network)
            comps.append(new_comp)
            nodes_so_far = nodes_so_far | new_comp
        next_node += 1
    return comps

def find_component(start_node, network):
    '''Returns the component that start_node belongs to, i.e., the set
    of nodes that are directly or indirectly connected to start_node.'''
    comp = set() # the component, as a set of node indices
    # For this algorithm, we will use another ADT, called a "queue".
    # As the name suggests, a queue is an ordered collection (like
    # a list), but it also has the property that we can only add
    # new elements at the end and remove elements from the front.
    # We can also check how long the queue is (really only need to
    # know if it's empty).
    # We start with only the start node:
    queue = make_queue()
    comp.add(start_node)
    enqueue(start_node, queue)
    while queue_length(queue) > 0: # while the queue is not empty
        # The idea is that as we discover new nodes belonging to the
        # component, we add them to the queue; so all nodes in the queue
        # are in the component, but all of their neighbours may not yet
        # be. Thus, we take the first node from the queue, check which
        # of its neighbours (if any) are new, and add them to the component
        # and to the queue.
        node = dequeue(queue)
        for nbr_node in neighbours(node, network):
            if nbr_node not in comp:
                comp.add(nbr_node)
                enqueue(nbr_node, queue)
    # When the loop stops, all neighbours of all nodes in the component
    # set are also in the component set; thus, we have found the whole
    # component
    return comp

## Implementation of queue interface:

def make_queue():
    '''Return a new, empty queue.'''
    return []

def enqueue(value, queue):
    '''Place value in queue.'''
    queue.append(value)

def dequeue(queue):
    '''Remove the first value in the queue and return it. Causes an
    error if the queue is empty.'''
    assert len(queue) > 0, "can't dequeue from an empty queue!"
    return queue.pop(0)

def queue_length(queue):
    '''Returns the length of the queue.'''
    return len(queue)


if __name__ == '__main__':
    # Test implementation with the example network from the lecture:
    links = [
        (0,4), (1,2), (1,5), (2,3), (2,8), (3,14), (4,9), (6,10),
        (6,12), (7,13), (8,14), (9,10), (9,15), (11,17), (13,19), (13,20),
        (15,21), (16,22), (17,18), (18,19), (19,26), (20,26),
        (21,27), (22,23), (23,28), (23,24), (24,29), (24,25),
        (26,30), (26,31), (28,29), (30,31)
    ]
    nw = create_network(32)
    for pair in links:
        add_link(pair[0], pair[1], nw)
    comps = components(nw)
    print(comps)
