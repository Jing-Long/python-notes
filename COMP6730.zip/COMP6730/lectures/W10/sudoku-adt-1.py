
## sketch of the recursive algorithm:

def solve(grid):
    '''Complete a partially filled sudoku grid. The function returns
    True if a solution exists, and false otherwise. If it returns True,
    the grid object on return contains the completed solution.'''
    # if the grid is full, it's a solution if all constraints are met:
    if is_full(grid):
        return is_valid(grid)
    # otherwise, find an empty square
    pos = find_empty_square(grid)
    for number in range(1,5): # number = 1,...,4
        set_square(pos, number, grid) # try placing number at pos
        if is_valid(grid): # if that doesn't violate a constraint,
            ok = solve(grid) # try solving the rest with this numer at pos
            if ok: # if that worked, we're done!
                return True
    # if no number worked, clear square at pos, and backtrack to
    # an earlier choice
    clear_square(pos, grid)
    return False

def make_example():
    '''Creates and returns an example Sudoku puzzle on a 4x4 grid.'''
    grid = make_grid(4)
    set_square((0, 2), 3, grid) # row 0, col 2: 3
    set_square((0, 3), 1, grid) # row 0, col 3: 1
    set_square((1, 0), 3, grid) # row 1, col 0: 3
    set_square((1, 1), 1, grid) # row 1, col 1: 1
    set_square((2, 1), 4, grid) # row 2, col 1: 4
    set_square((3, 0), 1, grid) # row 3, col 0: 1
    set_square((3, 2), 2, grid) # row 3, col 2: 2
    set_square((3, 3), 4, grid) # row 3, col 3: 4
    return grid

def make_grid(size):
    '''Return an empty size x size grid.'''
    return { (i,j) : 0 for i in range(size) for j in range(size) }

def set_square(pos, num, grid):
    '''Fill in number num in position pos in the grid.'''
    grid[pos] = num
    
def clear_square(pos, grid):
    '''Clear position pos in the grid.'''
    set_square(pos, 0, grid)

def find_empty_square(grid):
    '''Return a position in the grid which is currently empty. If there
    is no empty position, return None.'''
    for pos in grid.keys():
        if grid[pos] == 0:
            return pos
    return None

def is_full(grid):
    '''Return True iff grid is full (i.e., there is no empty square).'''
    return find_empty_square(grid) == None

def is_valid(grid):
    '''Check if a partially or completely filled grid satisfies all
    constraints. The sudoku constraints are no repetition of any
    number in any row, column, or "box". Also, all numbers should
    be between 1 and 4 (in general, 1 and size of the grid).'''
    # Idea: we'll write helper functions that count the number of
    # empty squares in a row/column/box, and that return the set of
    # values in a row/column/box. As long as there is no repetition
    # of numbers the empty count + the size of the set of numbers
    # in each row/column/box should equal 4; if it's less, that means
    # some number is repeated.
    for row in range(4):
        if count_empty([row], range(4), grid) + len(number_set([row], range(4), grid)) < 4:
            return False
    for col in range(4):
        if count_empty(range(4), [col], grid) + len(number_set(range(4), [col], grid)) < 4:
            return False
    # Each "box" in the grid can be defined by two ranges of row/col values
    # (there's probably a more elegant way to compute those ranges so that
    # we can do a loop over the boxes, but we'll figure that out another
    # day...)
    if count_empty([0,1],[0,1], grid) + len(number_set([0,1],[0,1], grid)) < 4:
        return False
    if count_empty([0,1],[2,3], grid) + len(number_set([0,1],[2,3], grid)) < 4:
        return False
    if count_empty([2,3],[0,1], grid) + len(number_set([2,3],[0,1], grid)) < 4:
        return False
    if count_empty([2,3],[2,3], grid) + len(number_set([2,3],[2,3], grid)) < 4:
        return False
    # If no constraint is violated, return True:
    return True

def count_empty(row_range, col_range, grid):
    '''Count the number of empty squares in an area of the grid defined
    by row_range and col_range (both must be enumerables of integers
    within the size of the grid).'''
    n = 0
    for row in row_range:
        for col in col_range:
            if grid[(row,col)] == 0:
                n += 1
    return n

def number_set(row_range, col_range, grid):
    '''Find the set of numbers in squares in an area of the grid defined
    by row_range and col_range (both must be enumerables of integers
    within the size of the grid).'''
    s = set()
    for row in row_range:
        for col in col_range:
            if grid[(row,col)] != 0:
                s.add(grid[(row,col)])
    return s

def print_grid(grid):
    '''Print the grid in a nicely formatted way. This assumes a 4x4 grid.
    Generalising to NxN is left as an exercise for the reader :)'''
    print('+----+')
    for row in range(4):
        content = ''.join([str(grid[(row,col)]) if grid[(row,col)] != 0 else ' '
                           for col in range(4)])
        print('|' + content + '|')
    print('+----+')

if __name__ == '__main__':
    grid = make_example()
    print("Starting sudoku grid:")
    print_grid(grid)
    ok = solve(grid)
    if ok:
        print("Solution found:")
        print_grid(grid)
    else:
        print("Not solvable!")
