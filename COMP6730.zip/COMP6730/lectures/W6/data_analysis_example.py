
import csv
import matplotlib.pyplot as plot

def mean(numbers):
    '''Returns the mean of a sequence of numbers.'''
    return sum(numbers) / len(numbers)

def median(numbers):
    '''Returns the median of a sequence of numbers.'''
    sorted_numbers = sorted(numbers)
    return sorted_numbers[len(numbers) // 2]

def count_by_quadrant(x, y):
    '''Count the pairs of values in x,y divided into quadrants
    by the x and y medians. x and y must be sequences of numbers,
    of the same length. Returns a list of counts in order
    [lower left, lower right, upper left, upper right]. Points
    exactly on a median are count half/half in both quadrants
    that it borders. Points exactly on both medians are ignored.'''
    assert len(x) == len(y)
    med_x = median(x)
    med_y = median(y)
    q_ll = 0
    q_ul = 0
    q_lr = 0
    q_ur = 0
    not_counted = 0
    for i in range(len(x)):
        if x[i] < med_x and y[i] < med_y:
            # lower left:
            q_ll += 1
        elif x[i] < med_x and y[i] > med_y:
            # upper left
            q_ul += 1
        elif x[i] < med_x and y[i] == med_y:
            # left, but on the y median
            q_ll += 0.5
            q_ul += 0.5
        elif x[i] > med_x and y[i] < med_y:
            # lower right
            q_lr += 1
        elif x[i] > med_x and y[i] > med_y:
            # upper right
            q_ur += 1
        elif x[i] > med_x and y[i] == med_y:
            # right, but on the y median
            q_lr += 0.5
            q_ur += 0.5
        elif x[i] == med_x and y[i] < med_y:
            # on the x median, lower
            q_ll += 0.5
            q_lr += 0.5
        elif x[i] == med_x and y[i] > med_y:
            # on the x median, upper
            q_ul += 0.5
            q_ur += 0.5
        else:
            not_counted += 1
    print(not_counted, "points on both medians not counted")
    return [q_ll, q_lr, q_ul, q_ur]

# read data from file
with open("qdata.csv") as csvfile:
    reader = csv.reader(csvfile)
    data = [ row for row in reader ]

# CSV file reader returns only strings; we need to convert
# the values in the table to integer or float (as apropriate).
data = [ [ int(row[0]), int(row[1]), float(row[2]), float(row[3]) ]
         for row in data ]

# extract columns
col0 = [ row[0] for row in data ]
col1 = [ row[1] for row in data ]
col2 = [ row[2] for row in data ]
col3 = [ row[3] for row in data ]

# plot histogram of all columns
plot.hist([col0, col1, col2, col3])
plot.legend(["col 0", "col 1", "col 2", "col 3"])
plot.xlabel("Value", fontsize="large")
plot.ylabel("Count", fontsize="large")
plot.show()

# compute normalised column values
ncol0 = [ row[0] / max(col0) for row in data ]
ncol1 = [ row[1] / max(col1) for row in data ]
ncol2 = [ row[2] / max(col2) for row in data ]
ncol3 = [ row[3] / max(col3) for row in data ]

plot.hist([ncol0, ncol1, ncol2, ncol3])
plot.legend(["col 0", "col 1", "col 2", "col 3"])
plot.xlabel("Value (relative to max)", fontsize="large")
plot.ylabel("Count", fontsize="large")
plot.show()

# scatter plot column 2 against column 3
plot.plot(col2, col3, linestyle='none', marker='o', color='blue')

# plot median lines on the scatter plot
med_col_2 = median(col2)
plot.plot([med_col_2, med_col_2], [min(col3), max(col3)], linestyle='solid', color='red')
med_col_3 = median(col3)
plot.plot([min(col2), max(col2)], [med_col_3, med_col_3], linestyle='solid', color='green')
plot.show()

# compute number of points in each of the quadrants created
# by the two medians
counts = count_by_quadrant(col2, col3)
print(counts[0] + counts[3], "points in lower left + upper right quadrant")
print(counts[1] + counts[2], "points in upper left + lower right quadrant")

## We did not get to using numpy (or other modules) during
## the lecture, so this part is not done.

#import numpy as np
#
## data as numpy 2d array:
# data = np.loadtxt("qdata.csv", delimiter=',')
