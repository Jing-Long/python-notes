
## Example from Lecture 1 in week 2, written with use of functions.

import math

# Give names to the constants involved:
m = 1
gravity = 9.81
theta_deg = 23
friction_coeff = 0.62

def deg_to_rad(x):
    '''Convert an angle given in degrees to radians.'''
    return x * math.pi / 180

def sin_of_deg(x):
    '''Returns the sine of an angle x, where x is in degrees.'''
    x_in_rad = deg_to_rad(x)
    return math.sin(x_in_rad)

def cos_of_deg(x):
    '''Returns the cosine of an angle x, where x is in degrees.'''
    x_in_rad = deg_to_rad(x)
    return math.cos(x_in_rad)

# Calculate the two forces:
pulling_force = m * gravity * sin_of_deg(theta)
print("pull: ", str(pulling_force))

friction_force = m * gravity * cos_of_deg(theta) * friction_coeff
print("friction: ", friction_force)

# The answer is found by comparing them
will_it_move = pulling_force > friction_force
print("moves: ", will_it_move)
