
# Example from Lectures in week 2 (calculation using a function).

def change_in_percent(old, new):
    '''Return change from old number to new number, as a
    percentage of the old number. The old number must be
    non-zero.'''
    diff = new - old
    return (diff / old) * 100

# call the function to compute the increase from 2017 to 2018
# student number:
increase = change_in_percent(523, 485)

# print the result:
print("The increase is", increase)
