# -*- coding: utf-8 -*-
"""
Created on Sun Aug 26 13:38:21 2018

@author: Administrator
"""


#Here is a completed solution to the problem we started on near the end
#of the lecture on Tuesday.

#In the lecture, we started with the idea of writing a function that
#checks if  the string contains a repeated substring of a given length:

def has_repeated_substring(s, length):
    '''Return True if string s contains a repeated substring of
    the given length.'''
    # loop over all substrings of the given length
    i = 0
    while i + length <= len(s):
        # the slice from i to i + length is the substring
        substr = s[i : i + length]
        # check if it appears in the later part of the string
        # (from i + length to the end) using the "in" operator:
        if substr in s[i + length : ]:
            return True
        i = i + 1
    # if we have gone over all indices up to len(s) - length
    # without finding a repeated substring, then there isn't
    # one:
    return False
#We can use this function to find the length of the longest repeated
#substring, as follows:

    # Idea: start with length = 0. As long as the string has
    # a repeated substring of length + 1, increment length and
    # check again. When the check returns False, the current
    # length is the longest.
    length = 0
    while has_repeated_substring(s, length + 1):
        length = length + 1
    return length
#However, because the function that checks if the string has a repeated 
#substring only returns True or False, it does not help us find out 
#what the repeated substring actually is.

#To solve the problem, we have to go back to our first function and 
#change it so that it returns the repeated substring, if one exists,
# and something else (that we can tell is different from a repeated 
#substring) if one does not. In the function below, we chose to use
# an empty string as the "no repeated substring found" marker 
#(because we are always looking for a repeated substring that is longer
#than the empty string, at least one character long).

def find_repeated_substring(s, length):
    '''If string s contains a repeated substring of at least the
    given length, return one such substring; otherwise return an
    empty string ('').'''
    # loop over all substrings of the given length
    i = 0
    while i + length <= len(s):
        # the slice from i to i + length is the substring
        substr = s[i : i + length]
        # check if it appears in the later part of the string
        # (from i + length to the end) using the "in" operator:
        if substr in s[i + length : ]:
            return substr
        i = i + 1
    # if we have gone over all indices up to len(s) - length
    # without finding a repeated substring, then there isn't
    # one:
    return ''

def longest_repeated_substring(s):
    '''Returns the longest repeated substring in string s.'''
    # Idea: start with length = 0. As long as we find a repeated
    # substring of length + 1, increment length and check again.
    # When the check fails (that is, when find_repeated_substring
    # return an empty string), the current length is the longest,
    # and we return the substring of that length.
    length = 0
    # Were, we need two variables: one to keep track of the longest
    # repeated substring found so far, and one to store the "next"
    # (length + 1) substring. We can't assign the result of checking
    # for a length + 1 substring to longest_substr directly, because
    # at the end of the loop, the check returns an empty string.
    longest_substr = ''
    next_substr = find_repeated_substring(s, length + 1)
    while next_substr != '':
        # We found a length + 1 substring, so we store it as the
        # new longest
        longest_substr = next_substr
        length = length + 1
        next_substr = find_repeated_substring(s, length + 1)
    return longest_substr
#We can test the function on the examples from the lecture slide:

#backpack -> ack
#singing -> ing
#independent -> nde
#philosophically -> phi
#monotone -> on
#wherever -> er
#repeated -> e
#programming -> r
#problem -> 
#However, for the string "banana", our function returns 'an' as the 
#longest repeated substring. 
#This is because in the find_repeated_substring function, specifically 
#in the test substr in s[i + length : ], we only check for
#non-overlapping repetitions. If we allowed overlapping 
#(but not identical) repetitions, then 'ana' would be the answer.