
# Example from Lecture 2 in week 2: robot to count how many boxes
# are in a stack. This is the iterative solution.

import robot

def count_boxes():
    '''Iterative version of the count-boxes-in-a-stack function.'''
    num_boxes = 0
    while robot.sense_color() != '':
        num_boxes = num_boxes + 1
        robot.lift_up()
    steps_to_go = num_boxes
    while steps_to_go > 0:
        robot.lift_down()
        steps_to_go = steps_to_go - 1
    return num_boxes

# Try with different stack sizes:

robot.init(height = 5, boxes = [["blue", "green", "yellow", "red"]])
#robot.init(height = 6, boxes = [["blue", "yellow", "blue", "yellow", "blue"]])
#robot.init(height = 7, boxes = "random")

print("Number of boxes in the stack:", count_boxes())
