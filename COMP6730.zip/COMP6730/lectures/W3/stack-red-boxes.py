
# Example from Lecture 1 in week 3: robot to find and stack two
# red boxes.

import robot

# Uncomment ONE of these to start the simulation from one of
# the three possible states.

robot.init(boxes = [["black"], [], ["red"], [], ["red"]])
#robot.init(boxes = [["red"], [], ["black"], [], ["red"]])
#robot.init(boxes = [["red"], [], ["red"], [], ["black"]])

def drive_left_twice():
    robot.drive_left()
    robot.drive_left()

def drive_right_twice():
    robot.drive_right()
    robot.drive_right()

def pickup_box():
    '''pick up box in front of gripper from shelf;
    assumes lift is down and gripper is folded'''
    robot.lift_up()
    robot.gripper_to_open()
    robot.lift_down()
    robot.gripper_to_closed()
    robot.lift_up()

def stack_box():
    '''stack box in gripper on top of another box,
    returning gripper to folded position and lift to down'''
    robot.gripper_to_folded()
    robot.lift_down()

def stack_red_boxes():
    if robot.sense_color() == 'red':
        drive_right_twice()
        if robot.sense_color() == 'red':
            # stack middle box on left
            robot.drive_right()
            pickup_box()
            drive_left_twice()
            stack_box()
        else:
            # stack left box on right
            robot.drive_left()
            pickup_box()
            drive_right_twice()
            drive_right_twice()
            stack_box()
    else:
        # stack middle box on right
        robot.drive_right()
        drive_right_twice()
        pickup_box()
        drive_right_twice()
        stack_box()

# call main function
stack_red_boxes()
