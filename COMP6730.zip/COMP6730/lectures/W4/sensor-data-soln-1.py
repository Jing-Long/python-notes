
# Uncomment these imports to use plotting functions:
#import numpy as np
#import matplotlib.pyplot as mpl

# For stats and other neat functions:
#import scipy
#import scipy.stats

time = [0.0, 0.09, 0.18, 0.27, 0.37, 0.45, 0.55, 0.64, 0.72, 0.82,
        0.91, 1.0, 1.09, 1.18, 1.27, 1.37, 1.45, 1.55, 1.64, 1.73,
        1.82, 1.91, 2.01, 2.09, 2.19, 2.28, 2.37, 2.46, 2.56, 2.65,
        2.74, 2.83, 2.92, 3.02, 3.1, 3.2, 3.29, 3.39, 3.47, 3.57,
        3.66, 3.75, 3.84, 3.93, 4.04, 4.13, 4.22, 4.31, 4.41, 4.5,
        4.59, 4.68, 4.78, 4.86, 4.96, 5.05, 5.14, 5.23, 5.32, 5.42,
        5.5, 5.6, 5.69, 5.78, 5.87, 5.97, 6.05, 6.15, 6.24, 6.32,
        6.42, 6.51, 6.6, 6.69, 6.79, 6.87, 6.97, 7.06, 7.15, 7.24,
        7.33, 7.43, 7.51, 7.61, 7.7, 7.79, 7.88, 7.98, 8.07, 8.16]

x = [0, 20, 53, 84, 118, 148, 183, 213, 248, 280, 312, 345, 376,
     410, 442, 478, 510, 546, 577, 612, 644, 677, 712, 743, 780,
     811, 848, 880, 916, 948, 985, 1016, 1052, 1085, 1116, 1153,
     1184, 1220, 1251, 1286, 1317, 1352, 1383, 1418, 1454, 1489,
     1519, 1554, 1586, 1616, 1651, 1681, 1717, 1749, 1784, 1815,
     1850, 1881, 1916, 1946, 1978, 2013, 2044, 2079, 2110, 2146,
     2178, 2214, 2245, 2282, 2314, 2347, 2382, 2415, 2451, 2484,
     2521, 2553, 2590, 2623, 2660, 2693, 2730, 2762, 2793, 2830,
     2861, 2898, 2930, 2964]

y = [36, 50, 56, 70, 100, 53, 54, 55, 56, 36, 58, 59, 60, 100,
     100, 100, 100, 36, 100, 100, 92, 100, 66, 67, 68, 100, 100,
     36, 73, 73, 100, 100, 100, 100, 100, 79, 100, 100, 80, 82,
     81, 81, 82, 100, 88, 36, 83, 84, 83, 100, 100, 100, 100, 86,
     100, 100, 100, 88, 88, 89, 91, 100, 95, 36, 94, 100, 100,
     100, 100, 100, 99, 97, 100, 100, 100, 100, 99, 100, 100,
     100, 36, 36, 100, 100, 100, 100, 100, 100, 100, 100]

# plot the raw data by time:
#mpl.plot(time, np.array(x) / np.max(x), linestyle='solid', linewidth=2, color='green')
#mpl.plot(time, np.array(y) / np.max(y), linestyle='solid', linewidth=2, color='red')
#mpl.ylim(0, 1.05)  # widen y-axis a bit
#mpl.show()

# plot the raw data as points:
#mpl.plot(np.array(x), np.array(y), linestyle='', marker='o', markersize=5, color='gray')
#mpl.ylim(30, 105)  # widen y-axis a bit
#mpl.show()

# compute the best fit line:

## First, compute the average slope between adjacent pairs of good
## samples (not outliers).
## To do this, we need to keep track of which was the index of the last
## good sample, so that when we encounter the next one we have a good
## pair. The second sample in the sequence (at index 1) is good, so we
## start with that as "last good index", and start the loop from the
## third:

last_good_i = 1
i = 2
sum_ratios = 0.0
count = 0
while i < len(y):
    # if element i is good...
    if 40 < y[i] < 100:
        # calculate differences:
        dy = y[i] - y[last_good_i]
        dx = x[i] - x[last_good_i]
        # calculate ratio and add to running sum:
        ratio = dy / dx
        sum_ratios = sum_ratios + ratio
        count = count + 1
        # current index now becomes the last good index
        last_good_i = i
    # increment index whether good or bad
    i = i + 1

a = sum_ratios / count

## Loop through again to find the average intercept. Here, we don't
## need to look at pairs, so just one index going through the whole
## sequence will do.
i = 0
sum_intercepts = 0.0
count = 0
while i < len(y):
    # if element i is good...
    if 40 < y[i] < 100:
        # calculate intercept
        y0 = y[i] - (a * x[i])
        # add to running sum:
        sum_intercepts = sum_intercepts + y0
        count = count + 1
    i = i + 1

b = sum_intercepts / count

print("a =", a, ", b =", b)

# plot the line y = a x + b
#w = np.linspace(np.min(x), np.max(x), len(x))
#mpl.plot(w, a * w + b, linestyle='solid', color='black')
#mpl.show()

# compute the residuals:
#r = y - (a * np.array(x) + b)

# plot the empirical cdf and compare it with the normal:
#mpl.plot(np.sort(r), np.linspace(0, 1, len(r)), linestyle='none', marker='o', markersize=5, color='red')
#w = np.linspace(np.min(r), np.max(r), len(r))
#mpl.plot(w, scipy.stats.norm.cdf(w, loc=np.mean(r), scale=np.std(r)), 'k-')

#mpl.show()
