#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  2 18:54:46 2018

@author: u5869920
"""

## (a)
#def sum_file(file):
#  #with open (file) as file: # add this line to fix the problem
#    total=0
#    for line in file:
#        # did not open the file first, here file is only the path
#        total=total+int(line.strip()) # runtime error: ValueError: invalid literal for int() with base 10: 'n'
#        # cannot convert the character in the path to integer
#    return total
#
#print("The sum is", sum_file("numbers.txt"))

## (b)
#file=open("numbers.txt")
#total=0
#while line in file: #syntax error: undefined name 'line'
#    print(line)
#    total=total+int(file.readline())# semantic error: 1+2+...+10==55, 
#    # but this gives 30, incorrect, only summed up part numbers
#file.close()
#print("The sum is",total)

## (c)
#def sum_file(filename):
#    file=open(filename)
#    try:
#        return sum(file.readlines()) # runtime error: TypeError: unsupported operand type(s) for +: 'int' and 'str'
#    # file.readlines() gives a list of strings, need to convert element type before using sum. 
#    # use return sum(int(item) for item in file.readlines()) to fix it.
#    finally:
#        file.close()
#
#print("The sum is", sum_file("numbers.txt"))

## (d)
#file=open("numbers.txt")
#total=0
#for line in file: #read a line, file position is at the end of this line
#    #print("line",line)
#    #print(file.readline())
#    total=total+int(file.readline())# read next line, file position is at the end of this next line
#file.close()
#print("The sum is",total)
#semantic error: 1+2+...+10==55, but this gives 30, incorrect, only summed up part numbers