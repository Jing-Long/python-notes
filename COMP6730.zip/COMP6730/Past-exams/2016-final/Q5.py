# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 17:49:25 2018

@author: Administrator
"""

def funX(a_list):
    x=a_list.pop(0)
    i=0
    while i<len(a_list):
        if a_list[i]==x:
            a_list.pop(i)
        else:
            i=i+1
    return a_list