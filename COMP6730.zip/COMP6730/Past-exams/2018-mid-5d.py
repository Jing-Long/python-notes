#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 29 19:50:47 2018

@author: u5869920
"""
import numpy as np

def funA(s):
    seq=np.array(s)
    seq[seq<0]=seq[seq<0]+1
    return seq

 need to update funB!!!
def funB(s):
    seq=s.copy()
    if s[0]>=0:
        funB(seq[1:])
    else:
        seq[0]=s[0]+1
        funB(seq[1:])
    return seq
