import numpy as np

def count_v(string):
    l_string=string.lower()
    c=0
    vowels=['a','e', 'i','o', 'u']
    for char in l_string:
	#print(char)
	if char in vowels:
            c=c+1
            #print(c,char)
        #else:
            #c=c
            #print(c, char)
    return c

count_v('Haha')

def a_function(a_parameter):
	seq=np.array(a_parameter)
	seq[seq<0]=seq[seq<0]+1
	return seq
	
