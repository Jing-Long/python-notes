# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 17:26:20 2018

@author: Administrator
"""

def funX(a_list,x):
    a_list.sort()
    index=0
    while a_list[index]<x:
        index=index+1
    return a_list[index]