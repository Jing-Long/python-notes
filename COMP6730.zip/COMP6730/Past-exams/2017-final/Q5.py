# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 17:33:23 2018

@author: Administrator
"""

def invert_dict(A):
    invA={}
    for key in A.keys():
        invA[A[key]]=key
    return invA
