def next_point(point,traj):
    for i in range(len(traj)):
	if traj[i]==point:
	   return traj[i+1]
   # return None
