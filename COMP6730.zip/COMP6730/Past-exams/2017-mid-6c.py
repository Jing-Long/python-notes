#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 29 19:35:56 2018

@author: u5869920
"""

def funY(seq):
    '''Return True when the seq is symmetrical'''
    if seq==seq[::-1]:
        return True
    else:
        return False
    
def funX(seq):
    '''Return True when the seq is symmetrical'''
    if len(seq)<=1:
        return True
    else:
        return seq[0]==seq[-1] and funX(seq[1:-1])