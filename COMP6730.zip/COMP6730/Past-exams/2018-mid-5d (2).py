#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 29 19:50:47 2018

@author: u5869920
"""
import numpy as np

def funA(s):
    seq=np.array(s)
    seq[seq<0]=seq[seq<0]+1
    return seq

def funB(seq_a):
    seq_b=[]
    print seq_a[0]
    if seq_a[0]<=0:
       seq_a[0]=seq_a[0]+1
    seq_b.append(seq_a[0])
    seq_b.extend(funB(seq_a[1:]))
    return seq_b
