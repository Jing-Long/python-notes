#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  5 11:34:03 2018

@author: u5869920
"""
import os

def recursive_file_listing(directory):
    filelist=[]
    current_directory = os.listdir(directory)
    for item in current_directory:
        new_path = directory + "/" + item
        if os.path.isfile(new_path):
            filelist.append(item)
        else:
            filelist.extend(recursive_file_listing(new_path))
    return filelist

recursive_file_listing('/students/u5869920/Desktop')