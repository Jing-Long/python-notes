#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  5 12:28:45 2018

@author: u5869920
"""

import numpy as np
import matplotlib.pyplot as plt

#image = np.zeros((2,3,3))     # create the image array (fill with 0s)
#image[0,0,:] = 1.0, 0.0, 0.0  # RGB for top-left (0,0) pixel
#image[0,1,:] = 0.0, 1.0, 0.0  # RGB for top-middle (1,0) pixel
#image[0,2,:] = 0.0, 0.0, 1.0  # RGB for top-right (2,0) pixel
#image[1,0,:] = 1.0, 1.0, 0.0  # RGB for row 2 left (0,1) pixel
#image[1,1,:] = 1.0, 1.0, 1.0  # RGB for row 2 middle (1,1) pixel
#image[1,2,:] = 0.0, 0.0, 0.0  # RGB for row 2 right (2,1) pixel
#plt.imshow(image, interpolation='none')
#plt.show()

def read_image(filename):
    with open(filename) as file:
        identifier=file.readline().rstrip('\n')
        if identifier=='P3':
            x,y=file.readline().rstrip('\n').split(' ')
            max_color=int(file.readline().rstrip('\n'))
            image=np.zeros((int(x),int(y),3))
            all_number=[]
            for line in file:
                line=line.rstrip('\n').split(' ')
                number_line=[int(item)/max_color for item in line if item!='']
                chunks = [number_line[k:k+3] for k in range(0, len(number_line), 3)]
                all_number.extend(chunks)
            k=0
            for i in range(int(x)):
                for j in range(int(y)):
                    image[i,j,:]=all_number[k]
                    k+=1
    plt.imshow(image, interpolation='none')
    plt.show()        
                    