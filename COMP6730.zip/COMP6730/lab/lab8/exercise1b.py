#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  5 10:32:03 2018

@author: u5869920
"""

def count_non_empty_lines(filename):
    data=open(filename,'r')
    count=0
    for line in data:
        print(line)
        if line!='\n':# count non-empty line, actually there is an 
                      # invisible \n.
            count+=1
    data.close()
    return count
            