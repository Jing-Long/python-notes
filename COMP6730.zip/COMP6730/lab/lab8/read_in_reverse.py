#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  5 10:48:21 2018

@author: u5869920
"""

def read_in_reverse1(filename):
    filelist=[]
    file=open(filename,'r')
    for line in file:
        filelist.append(line)
        #print(filelist)
    i=len(filelist)-1
    while i>=0:
        print(filelist[i])
        i=i-1
        
def read_in_reverse2(filename):
    file=open(filename,'r')
    for line in file.readlines()[::-1]:
        print(line)
    file.close()
            
            