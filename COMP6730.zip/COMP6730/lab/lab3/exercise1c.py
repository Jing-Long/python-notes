# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 20:01:41 2018

@author: u5869920
"""

def median(a,b,c):
    '''Return the median of three numbers'''
    if a<=b<=c or c<=b<=a:
        return b
    elif b<=c<=a or a<=c<=b:
        return c
    elif c<=a<=b or b<=a<=c:
        return a
    
print(median(1,5,9))