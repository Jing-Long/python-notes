#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 11:51:42 2018

@author: u5869920
"""
def identify_prime(n):
    i=2
    if n==1 or n==2:
        return True
    else:
        while i<n:
            if n%i==0:
                return False
            i=i+1
        return True
    
def prime_factors(n):
    i=1
    while i<=n:
        if n%i==0 and identify_prime(i):
            print(i)
        i=i+1
        
def multiplicity_of_factors(n):
    i=2
    while i<=n:
        times=1
        if n%i==0 and identify_prime(i):
            division=n//i
            while (division)%i==0:
                times=times+1
                division=division//i
            print(n, "includes", times, "prime factor", i)
        i=i+1    
    
def check_perfect_number(n):
    i=1
    sum=0
    while i<n:
       if n%i==0:
          sum=sum+i
       i=i+1    
    if sum==n:
        print(n,"is a perfect number")
        return n
    else:
        print(n,"is not a perfect number")
        
def return_perfect_number(n):
    i=1
    sum=0
    while i<n:
       if n%i==0:
          sum=sum+i
       i=i+1    
    if sum==n:
        return n       
    
def perfect_number_in_range(n):
    i=1
    while i<n:
        result=return_perfect_number(i)
        if result!=None:
            print(result)
        i=i+1
    print("these are all perfect numbers between 1 and", n)