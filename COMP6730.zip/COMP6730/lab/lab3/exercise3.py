#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 11:23:12 2018

@author: u5869920
"""

import math

def square_root(a):
    '''Return the square root of a (Babylonian algorithm). 
    Assumption: a is a non-negative number.'''
    x=1
    while abs(x**2-a)>1e-6:
        x=(x+a/x)/2
        print(x)
    print('math mode square root is', math.sqrt(a))
    return 'the square root of using this method is', x
    