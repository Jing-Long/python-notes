# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 19:58:49 2018

@author: u5869920
"""

def print_grade(mark):
    if  mark >= 80:
        print("High Distinction")
    elif 80 > mark >= 70:
        print("Distinction")
    elif 70 > mark >= 60:
        print("Credit")
    elif 60 > mark >= 50:
        print("Pass")
    else:# mark < 50:
        print("Fail")
        
print(print_grade(100))