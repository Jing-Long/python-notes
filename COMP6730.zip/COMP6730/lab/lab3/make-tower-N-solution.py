
import robot

def make_tower():
    '''Stack all boxes on the shelf into a tower.
    Assumptions: All boxes are on the shelf, and one space apart.
    The robot is at its starting position (left end of the shelf,
    with the lift down and gripper folded).'''
    n_boxes = count_boxes_on_shelf()
    print("counted", n_boxes, "boxes")
    # the counting function returns the robot to the starting
    # position, but we need it to be one step to the right (so
    # that the gripper is in front of the first box) before
    # we start stacking
    robot.drive_right()
    make_tower_of_n_boxes(n_boxes)

def count_boxes_on_shelf():
    '''Count how many boxes (stacks) there are on the shelf.
    Assumptions: Robot is at the left end of the shelf; this
    means the robot sensor is in front of the left-most stack
    at the beginning. Stacks are two steps apart.'''
    num_stacks = 0
    # idea: drive right by two steps until we don't see a box;
    # when that happens, we have reached the end of the shelf.
    while robot.sense_color() != '':
        num_stacks = num_stacks + 1
        drive_right_n_steps(2)
    # return the robot to the starting position
    drive_left_n_steps(num_stacks * 2)
    return num_stacks

def make_tower_of_n_boxes(n_boxes):
    '''Build a tower of n boxes that are on the shelf (with one
    empty space between each box).
    Assumptions: The robot is in front of the left-most box on
    the shelf, and the lift is down.'''
    # position lift above the first box
    robot.lift_up()
    # repeat for all boxes except the last:
    while n_boxes > 1:
        print(n_boxes - 1, "boxes to go")
        pickup_next()
        drive_right_n_steps(2)
        n_boxes = n_boxes - 1
    # finally, park the robot
    print("done, parking the robot!")
    robot.gripper_to_folded()
    robot.lift_down()
    

def pickup_next():
    '''Release the box in gripper (if any) and pick up the one below.
    Assumption: robot is in front of a box/stack; lift is at level 1.'''
    robot.gripper_to_open()
    robot.lift_down()
    robot.gripper_to_closed()
    robot.lift_up()

def drive_right_n_steps(n):
    '''Move the robot right by n steps. n must be an integer >= 0.'''
    while n > 0:
        assert n >= 0
        robot.drive_right()
        n = n - 1

def drive_left_n_steps(n):
    '''Move the robot left by n steps. n must be an integer >= 0.'''
    while n > 0:
        assert n >= 0
        robot.drive_left()
        n = n - 1
    
# Define a testing function:

def test_make_tower(n):
    # start a simulation with n boxes:
    robot.init(width = 2*n - 1, boxes = "flat")
    # call make_tower:
    make_tower()
