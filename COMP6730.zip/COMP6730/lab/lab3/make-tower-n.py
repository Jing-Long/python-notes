#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 10:17:03 2018

@author: u5869920
"""
import robot


def move_to_next_stack():
    '''move robot two steps right'''
    robot.drive_right()
    robot.drive_right()

def pickup_next():
    '''Release the box in gripper (if any) and pick up the one below.
    Assumption: robot is in front of a box/stack; lift is at level 1.'''
    robot.gripper_to_open()
    robot.lift_down()
    robot.gripper_to_closed()
    robot.lift_up()

def make_tower(n):
    '''Stack n blocks to make a tower.'''
    robot.init(width = 2*n-1, boxes = "flat")
    # position above first box
    robot.drive_right()
    robot.lift_up()
    i=1
    while i<n:
        # pick up, move right and repeat for n-1 times
        pickup_next()
        move_to_next_stack()
        i=i+1
    # tower is done, park the robot
    robot.gripper_to_folded()
    robot.lift_down()
        
    