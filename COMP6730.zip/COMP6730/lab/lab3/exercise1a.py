# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 19:47:08 2018

@author: u5869920
"""

def print_grade(mark):
    if mark >= 80:
        print("High Distinction")
    else:
        if 80 > mark >= 70:
            print("Distinction")
        else:
            if 70 > mark >= 60:
                print("Credit")
            else:
                if 60 > mark >= 50:
                    print("Pass")
                else:# mark < 50:
                    print("Fail")

print(print_grade(100))