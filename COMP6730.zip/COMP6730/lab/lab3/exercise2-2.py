#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 10:44:58 2018

@author: u5869920
"""

import robot

robot.init(height = 5, boxes = [["black", "blue", "white", "red"]])

def find(colour):
    '''Find the height of given color. 
    Assumption: robot sensor is in front of a box/stack; lift is at level 1.'''
    height=1
    while robot.sense_color()!='':
        if robot.sense_color()==colour:
            return "the height of "+ colour+" box is", height
        else:
            robot.lift_up()
            height=height+1
    print (-1, "the "+colour+" box is not in the stack")