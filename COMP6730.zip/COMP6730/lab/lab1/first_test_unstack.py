#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  3 10:50:16 2018

@author: u5869920
"""
import robot
robot.init() # the default gripper mode is folded 
             # init(ip_address = None, visualise = True, width = 5, height = 2,
             # pos = -1, boxes = [["red"], [], ["green"], [], ["blue"]])
def drive_right_twice():     
    robot.drive_right()
    robot.drive_right()

def drive_right_four():
    drive_right_twice()
    drive_right_twice()

def drive_left_twice():
    robot.drive_left()
    robot.drive_left()

def drive_left_four():
    drive_left_twice()
    drive_left_twice()

def grab_up_cube():
    robot.gripper_to_open()
    robot.lift_up()
    robot.gripper_to_closed()

def grab_bottom_cube():
    robot.gripper_to_open()
    robot.lift_down()
    robot.gripper_to_closed()
  
def grab_right_cube():
    robot.drive_right()
    drive_right_twice()
    robot.lift_up()
    grab_bottom_cube()
    robot.lift_up()
        
def left_to_fold():
    drive_left_twice()
    robot.gripper_to_folded()
    drive_right_four()
    

def right_to_fold():
    drive_right_twice()
    robot.gripper_to_folded()
    drive_left_four()

def left_to_middle():
    right_to_fold()
    grab_bottom_cube()
    drive_right_twice()
    robot.gripper_to_open()
    robot.lift_up()
    left_to_fold()
    robot.gripper_to_closed()
    drive_left_four()
    robot.lift_down()


def swap_left_and_middle():
    grab_right_cube()
    left_to_middle()

#swap_left_and_middle()
   
def swap_middle_and_right():
    grab_right_cube()
    left_to_fold()
    grab_bottom_cube()
    drive_left_twice()
    robot.gripper_to_open()
    robot.lift_up()
    right_to_fold()
    robot.gripper_to_closed()
    drive_right_four()
    robot.lift_down()
    robot.gripper_to_open()
#swap_middle_and_right()
    
def swap_left_and_right():
    swap_middle_and_right()
    robot.lift_up()
    drive_left_twice()
    grab_bottom_cube()
    robot.lift_up()
    left_to_middle()
    robot.gripper_to_open()
    robot.lift_up()
    robot.gripper_to_folded()
    robot.drive_left()
    robot.lift_down()
    swap_middle_and_right()

swap_left_and_right()   

    
    
    
    
    
    
    
    
