#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  3 11:12:42 2018

@author: u5869920
"""
from datetime import date

print("Today's date is:", date.today())
print("The sum of", 2, "and", 3, "is", 2+3)