#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 20:20:24 2018

@author: u5869920
"""
x=[1,-2,0,-4]#[-1,0,1]#[1,2,4,7]
## Exercise 1
## (a) wrong
#def find_max(x, y):
#    c = []
#    for i in x:
#        for j in y:
#            c.append(x[i] - y[j]) # IndexError: list index out of range
#            # the element in the list cannot be used as index here
#    return max(c)
#
#print("The max difference is ", find_max(x, x))


## (b) wrong
#def find_max(x, y):
#    d = 0
#    for i in x and j in y: # NameError: name 'j' is not defined
#        # syntax is incorrect, should use two for loops
#        d = max(d, i - j)
#    return d
#
#print("The max difference is ", find_max(x, x))

## (c) wrong 
#def find_max(y):
#    z = x[0] * y
#    print(z)
#    for i in range(len(x)):
#        x[i] = y * x[i] # this changed the original list, when y==-1, x[i] 
#        # cannot be negative, or the max negtaive x[i] *(-1) will be return as 
#        # the minimum.
#        if x[i] > z:
#            z = x[i]
#    return z
#
#print("The max value is ", find_max(1))
#print("The min value is ", find_max(-1))
#print("The max difference is ", find_max(1) - find_max(-1))

## (d) wrong
#def find max(x): # the function definition is wrong, should have an underscore
#                 # max() is a built-in function
#    x=x.sort() # list method returns None, so this will assign None to list x.
#    return x[-1] - x[1] # TypeError: 'NoneType' object is not subscriptable
#    # should return x[-1]-x[0] to find max difference in list x.
#print("The max difference is ", find max(x))