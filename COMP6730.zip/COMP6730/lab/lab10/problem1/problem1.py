
## REMEMBER THAT THIS FILE MUST NOT CONTAIN ANYTHING OTHER THAN YOUR
## FUNCTION DEFINITION, IMPORT STATEMENTS AND COMMENTS. You can use
## docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very
## beginning of the function suite. Everywhere else you should use
## comments.

## Modify the following function definition so that it computes and
## returns the correct answer to the problem. (The statement "pass"
## is just a placeholder: you should replace it.)

def approximate_integral(lower, upper, nterms):
    # divide the interval into nterms even-sized parts
    delta = (upper - lower) / nterms
    total = 0
    while lower+delta <= upper: # avoid comapre float point numbers
        # compute area from lower to lower + delta
        area = ((lower)**3 + (lower + delta)**3) * delta / 2
	# add to total area
        total = total + area
        lower = lower + delta
        print('end',lower,lower+delta)
    return total
