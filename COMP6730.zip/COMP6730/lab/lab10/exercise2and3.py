#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 30 21:22:51 2018

@author: u5869920
"""
## Exercise 2
def funX(a_list):
    index = 0
    while index < len(sorted(a_list)) // 2:
        index = index + 1
    return sorted(a_list)[index]

# (a) This function returns the median of a list. If the list length is even,
#     it returns the first element on the right of the median when the list is 
#     sorted ascendingly.
 
## (b) most efficient version
def funX(a_list):
    return sorted(a_list)[len(sorted(a_list)) // 2]

## Exercise 3
def funY(x):
    i = 0
    while i < len(x):
        i = i + x[i] % len(x)
    return i

# (a) x=[-1] will cause funY to get stuck in a infinite loop, cause 0 always <1.
#     x=[3,5] returns 2.
    
# (b) TypeError: if the list contains a string, the + and % cannot work, x==['a']
#                list cannot be list of lists, x==[[1],[2]]
#     Infinite loop: the conditon can never be satisfied for some list, x==[-1]    
      