
## REMEMBER THAT THIS FILE MUST NOT CONTAIN ANYTHING OTHER THAN YOUR
## FUNCTION DEFINITION, IMPORT STATEMENTS AND COMMENTS. You can use
## docstrings to document your functions, but a docstring should only
## be used inside a function definition, an then only at the very
## beginning of the function suite. Everywhere else you should use
## comments.

## Modify the following function definition so that it computes and
## returns the correct answer to the problem. (The return statement
## is just a placeholder: you should replace it.)

def unnest(alist):
    flat=[]
    for i in range(len(alist)):
        if type(alist[i])!=list:
            flat.append(alist[i])
        else:
            flat.extend(unnest(alist[i]))
    return flat
