# -*- coding: utf-8 -*-

from testing import ModuleTestBase, FunctionTestBase, FunctionTestReturningFloat

class IntervalIntersectionTest (ModuleTestBase):

    fun_name = "interval_intersection"

    tests = (
        ((0, 2, 4, 7.5), 0.0, "no intersection (uA < lB)"),
        ((1, 3, 2.5, 6), 0.5, "intersection is [2.5, 3]"),
        ((1, 3, 1.5, 5), 1.5, "intersection is [1.5, 3]"),
        ((0, 2, -2, 1.5), 1.5, "intersection is [0, 1.5]"),
        ((1, 3, 0, 3.5), 2.0, "A is contained in B"),
        ((1.5, 3.5, 0, 3.5), 2.0, "A is contained in B"),
    )

    def run_function_tests(self, _suppress_output = False):
        ok, fun, msg = self.find_function(self.fun_name)
        if not ok:
            return False, msg
        if fun is None:
            return False, msg
        ft = FunctionTestReturningFloat(fun, self.tests,
                                        precision = 1e-5,
                                        verbose = self.verbose - 1,
                                        raise_exceptions = self.raise_exceptions,
                                        suppress_output = _suppress_output)
        ok, msg = ft.run()
        return ok, msg


    def run(self):
        print("checking function " + self.fun_name +
              " in file " + self.filepath)
        print()
        ok, msg = self.run_function_tests(False)
        print(msg)

    ## end IntervalIntersectionTest


## To produce less verbose output, change verbose from 3 to 2 or 1:

IntervalIntersectionTest("problem5.py", verbose = 3).run()
