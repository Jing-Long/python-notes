#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 18:33:05 2018

@author: u5869920
"""

def nesting_depth(nested_list):
    depth=0
    for item in nested_list:
        if type(item)==list:
            depth=nesting_depth(item)+1
    return depth