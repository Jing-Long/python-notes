#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 17:15:32 2018

@author: u5869920
"""
## (a)
def allbut(a_list, index):
    my_short_list=a_list.copy()
    my_short_list.pop(index)
    return my_short_list

##(b)
def slice_in_place(a_list, start, end):
    print('original list:',a_list)
    for i in range(start): # remove items before start
        a_list.pop(i)
        print('delete before slice start:',a_list)
    new_end=end-start
    while len(a_list)>new_end:
        a_list.pop(-1) # delete from the end of the list
    #or a_list.pop(new_end) # delete after the end of the slice
        print('delete after slice end:',a_list)
           

my_list = [1, 2, 3, 4]
a_list=[i for i in range(10)]