#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 19:44:35 2018

@author: u5869920
"""
def list_permutations(alist):
    if len(alist)==0:
        return [[]]
    else:
        all_permutations=[]
        for i in range(len(alist)):
            first_item=alist[i]
            other_items=alist[:i]+alist[i+1:]
            other_permutations=list_permutations(other_items)
            one_permutation=[[first_item]+perm for perm in other_permutations]
            all_permutations.extend(one_permutation)
        return all_permutations

def permutations(n):
    return list_permutations(list(range(1,n+1)))