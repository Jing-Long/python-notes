#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 16:37:18 2018

@author: u5869920
"""


def find_max(seq):
    i = 0
    if i == len(seq) - 1: # if only one element in the seq
        return seq[0] # return this element
    else:
        first = seq[i]
        i = i + 1
        max_of_rest = find_max(seq[i:])
    return max(first, max_of_rest)

def find_max1(seq):
    return max(seq)

def find_max2(seq):
    max_value=seq[0]
    for item in seq:
        if item>max_value:
            max_value=item
    return max_value