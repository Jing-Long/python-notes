#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 18:05:05 2018

@author: u5869920
"""
from random import shuffle
## (a)
def perfect_shuffle(a_list):
    my_shuffled_list =a_list.copy()
    shuffle(my_shuffled_list)
    return my_shuffled_list

## (b)
def perfect_shuffle_in_place(a_list):
    original_list=a_list.copy()
    shuffle(a_list) # alreadt changed the order in original a_list
    count=1
    print(a_list)
    # count how many shuffles to restore
    while a_list!=original_list:
        shuffle(a_list)
        count+=1
    print('It needs', count,'shuffles before the list becomes equal to the original list.')
    