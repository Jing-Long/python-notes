#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 15:43:28 2018

@author: u5869920
"""

##Function 1
def make_list_of_lists(n):
    the_list = []
    sublist = []
    while n > 0:
        #the_list.append(sublist) # this lineis wrong, refer to the sublist
        # when sublist changes, the_list changes as well
        # should use this following line:
        the_list.append(sublist.copy())
        sublist.append(len(sublist) + 1)
        n = n - 1
    return the_list
#

##Function 2
#def make_list_of_lists(n):
#    the_list = []
#    sublist = []
#    for i in range(n):
#        #the_list.extend(sublist) # extend put elements in all lists in a list,
#        #should use append instead
#        the_list.append(sublist.copy()) 
#        #sublist = sublist.insert(len(sublist), i) # list method returns None.
#        sublist.insert(len(sublist), i+1) # value should +1
#    return the_list
