
## Analysis of BoM temperature data.

import csv

def convert_to_number(a_string):
    '''Convert a string to a floating point number. Checks that the
    string is non-empty, but does no other format checks. Returns
    None if the string is empty (representing a missing value).'''
    if len(a_string) == 0:
        return None
    else:
        return float(a_string)

def read_temperature_file(filepath):
    '''Read a (min or max) temperature data file. The function returns
    a table in list-of-rows form. Each row has the date (year, month
    and day) and temperature columns; these are converted to numeric
    types (int for the date, float for the temperature), except that
    the temperature field is set to None where a value is missing.'''
    with open(filepath) as csvfile:
        reader = csv.reader(csvfile)
        table = [ row for row in reader ]
    table = table[1:] # remove the header
    num_table = [ [ int(row[2]), int(row[3]), int(row[4]),
                    convert_to_number(row[5]) ] for row in table ]
    return num_table

def monthly_average(temp_table, year, month):
    '''Compute the average over a specific month in a specific year
    from a temperature table. The table should have the format returned
    by read_temperature_table.'''
    total = 0
    count = 0
    for row in temp_table:
        if row[0] == year and row[1] == month:
            if row[3] is not None:
                total += row[3]
                count += 1
    assert count > 0 # can't compute average if there is no data
    return total / count

# read the minimum temperature data file:

temp_table = read_temperature_file("daily-min-temp-CBR.csv")

# compute averages for the months of June, July and August, for
# 2009 - 2018 (data from 2008 doesn't start until September).

years = list(range(2009, 2019))
june_avgs = [ [ monthly_average(temp_table, year, 6), year ] for year in years ]
july_avgs = [ [ monthly_average(temp_table, year, 7), year ] for year in years ]
aug_avgs = [ [ monthly_average(temp_table, year, 8), year ] for year in years ]

# The averages temperature of each month is paired with the year; this
# is so that we can sort on the average temperature and still keep track
# of the associated year. Default sort order is increasing, so we end
# up with coldest first.

june_avgs = sorted(june_avgs)
july_avgs = sorted(july_avgs)
aug_avgs = sorted(aug_avgs)

def print_rank_table(june, july, aug):
    '''Print the years sorted by coldness for the three winter months
    as a nice table. This function prints only the years, so it will
    work for different measures of "coldness".'''
    assert len(june) == len(july) and len(july) == len(aug)
    print(" June  July  August")
    for i in range(len(june)):
        print(" " + str(june[i][1]) + "  " + str(july[i][1]) + "   " + str(aug[i][1]))


# Print a summary table:
print("Coldest years (by average min temperature):")
print_rank_table(june_avgs, july_avgs, aug_avgs)

# Let's try the same thing but counting the number of nights with
# subzero temperature instead:

def count_sub_zero(temp_table, year, month):
    '''Count the number of sub-zero entries in a specific month in a
    specific year from a temperature table. The table should have the
    format returned by read_temperature_table.'''
    count = 0
    for row in temp_table:
        if row[0] == year and row[1] == month:
            if row[3] is not None:
                if row[3] < 0:
                    count += 1
    return count

june_count = [ [ count_sub_zero(temp_table, year, 6), year ] for year in years ]
july_count = [ [ count_sub_zero(temp_table, year, 7), year ] for year in years ]
aug_count = [ [ count_sub_zero(temp_table, year, 8), year ] for year in years ]

# We want the years with the highest number of sub-zero nights at the
# top of the table, so we have to reverse the sort order.
june_count = sorted(june_count, reverse=True)
july_count = sorted(july_count, reverse=True)
aug_count = sorted(aug_count, reverse=True)

print("Coldest years (by number of sub-zero nights):")
print_rank_table(june_count, july_count, aug_count)
