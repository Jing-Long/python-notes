#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 21 10:58:40 2018

@author: u5869920
"""

import matplotlib.pyplot as plt
import numpy as np
import csv

#def get_winter(year, data):


with open("daily-min-temp-CBR.csv") as csvfile:
    reader = csv.reader(csvfile)
    table = [ row for row in reader ]
    
table_no_header=table[1:]
minT=[]
year=[]
month=[]
day=[]
for row in table_no_header:
    year.append(row[2])
    month.append(row[3])
    day.append(row[4])
    if row[5] == '':
       minT.append(-99)
    else:
       minT.append(float(row[5]))
       
# 1. define winter is the month has the lowest average minimum T 
#     and months before and after this month.       
def average_month_T(month_number):
    count=0
    total_T=0    
    for i in range(len(table_no_header)): 
       if int(month[i]) == month_number:
           if minT[i]==-99:
               continue
           else:
               total_T=total_T+minT[i]
               count=count+1
    return total_T/count 

all_average_minT=[]        
for i in range(1,13):
    average_minT=average_month_T(i)
    all_average_minT.append(average_minT)
    print('The average minimum temperature of month',i,'is',average_minT)
print('The coldest month has average minimum temperature',
      min(all_average_minT),' This is month 7, so we define the winter is the months of June, July and August.') 

# 2. Count how many nights in winter have sub-zero T to evaluate how 
#    cold the Canberra winter is
total_winter_days=0
sub_zero_days=0
for i in range(len(table_no_header)): 
    if int(month[i]) == 7 or int(month[i]) ==8 or int(month[i]) ==9:
        total_winter_days=total_winter_days+1
        if minT[i]==-99:
           continue
        elif minT[i]<0:
            sub_zero_days=sub_zero_days+1
print('In',total_winter_days,'days of winter, at least',sub_zero_days,'nights have the sub-zero temperature.')

# 3. In my defination, any nights have temperate lower than 10 are winter.
total_days=0
sub_10_days=0
for i in range(len(table_no_header)): 
        total_days=total_days+1
        if minT[i]==-99:
           continue
        elif minT[i]<10:
            sub_10_days=sub_10_days+1
print('In',total_days,'days, at least',sub_10_days,'nights have the sub-10 temperature.')

# 4. 