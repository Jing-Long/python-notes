#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 15:15:15 2018

@author: u5869920
"""
def unity_list(n):
    '''Return a list of n elements, each element is 1.'''
    return [1]*n

def step_list(n,k):
    '''Return a list of integers that counts up 
       from -n to n, in steps of k.'''
    return [x for x in range(-n,n+k,k)]

def my_list(n):
    '''Return a list of n integers whose value is the same as their index+1.'''
    return [i+1 for i in range(n)]