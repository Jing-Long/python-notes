#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 11:05:32 2018

@author: u5869920
"""

def average(numbers):
    '''Return the average of numbers'''
    return sum(numbers)/len(numbers)


def most_average(numbers):
    '''Return the  the number in the input that is closest 
       to the average of the numbers.'''
    closest_number=abs(numbers[0]-average(numbers))
    for i in range(len(numbers)):
        if abs(numbers[i]-average(numbers))<abs(closest_number-average(numbers)):
            closest_number=numbers[i]    
    return closest_number

def count_negative(numbers):
    count=0
    for i in numbers:
        if i<0:
            count=count+1
    return count