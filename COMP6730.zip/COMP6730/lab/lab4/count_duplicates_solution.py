#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 28 21:46:34 2018

@author: u5869920
"""

def count_duplicates_v1(seq):
    '''Return the number of duplicate elements in sequence. The number
    of duplicates can be defined as the length of the sequence minus the
    number of unique elements in it.'''
    # Idea: for each position in the sequence, search backward to see
    # if the element at that position has appeared before; if it has,
    # then it's a duplicate.
    # In the worst case, this will take 0 + 1 + .. + n = n(n-1)/2,
    # comparisons; the worst case happens when all elements in the
    # sequence are unique, so that the search goes all the way to
    # the beginning every time.
    n_dups = 0
    # In this version, we'll use only while loops:
    index = 0
    while index < len(seq):
        # backward search from index - 1 for an element equal to seq[index].
        # we use a boolean variable (found) to stop the loop as soon as an
        # equal element is found; the other stopping condition is that the
        # backward index is < 0.
        b_index = index - 1
        found = False
        while (b_index >= 0) and not found:
            if seq[b_index] == seq[index]:
                found = True
                n_dups = n_dups + 1
            b_index = b_index - 1
        # increment index for the main loop
        index = index + 1
    return n_dups


def count_duplicates_v2(seq):
    '''Return the number of duplicate elements in sequence. The number
    of duplicates can be defined as the length of the sequence minus the
    number of unique elements in it.'''
    n_dups = 0
    # Same idea as v1, but using a for loop, slicing and the `in` operator:
    for index in range(len(seq)):
        # does the element at index appear in the sub-sequence up to
        # (but not including) index?
        if seq[index] in seq[:index]:
            n_dups = n_dups + 1
    return n_dups


def count_duplicates_v3(seq):
    '''Return the number of duplicate elements in sequence. The number
    of duplicates can be defined as the length of the sequence minus the
    number of unique elements in it.'''
    # A different idea: create a new list of unique elements (i.e.,
    # the same as the input sequence, but without any repetitions),
    # then we can count the duplicates exactly as the docstring says:
    # the length of the sequence minus the number of unique elements.
    unique_elems = []
    # for each element in the sequence:
    for elem in seq:
        # if we haven't seen this one before...
        if elem not in unique_elems:
            # then we add it to the list:
            unique_elems = unique_elems + [ elem ]
    # at the end of the loop, unique_elems has exactly one copy of
    # every element in the input sequence.
    return len(seq) - len(unique_elems)


def count_duplicates_v4(seq):
    '''Return the number of duplicate elements in sequence. The number
    of duplicates can be defined as the length of the sequence minus the
    number of unique elements in it.'''
    # Another idea: If we sort the input sequence, then all identical
    # copies of elements will be next to each other. Therefore, we can
    # check if an element is a duplicate by just comparing it with the
    # one just before it.
    # However, this solution only works if all elements in the input
    # sequence are comparable (so that they can be sorted); it would
    # not work if, for example, the input contains a mix of numbers
    # and strings.
    sorted_seq = sorted(seq)
    n_dups = 0
    # Start the loop from index 1 instead of 0, so that we can compare
    # index and index - 1 (we could do this with a while loop too).
    for index in range(1, len(sorted_seq)):
        if sorted_seq[index] == sorted_seq[index - 1]:
            n_dups = n_dups + 1
    return n_dups