#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 16:03:13 2018

@author: u5869920
"""

def count_in_bin(values,lower,upper):
    count=0
    for element in values:
        if lower < element <= upper:
            count=count+1
    return count
            
def count_in_bin_another(values,lower,upper):           
    count=sum(lower < element <= upper for element in values)
    return count

def histogram(values, dividers):
    borders=np.append(np.append(dividers,min(values)-0.0001),max(values))
    mylist=sorted(borders)
    hist=[]
    i=0
    while i<len(mylist)-1:
        x=count_in_bin(values,mylist[i],mylist[i+1])
        hist = hist + [x]
        i=i+1
    return hist


# use to check result of histogram fu nction
import numpy.random as rnd
import matplotlib.pyplot as plt
import numpy as np

values = rnd.normal(0, 1, 50)
range = np.max(values) - np.min(values)
dividers = (np.arange(1, 10) * (range / 10)) + np.min(values)

plt.hist(values)       
print(histogram(values,dividers))  