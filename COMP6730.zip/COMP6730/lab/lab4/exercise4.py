#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 11:57:55 2018

@author: u5869920
"""
def is_increasing(seq):
    i=0
    while i<len(seq)-1:
        if seq[i+1]<seq[i]:
            return False
        i=i+1
    return True

# wrong example codes
#Function 1
def is_increasing1(seq):
    i = 0
    while i < len(seq):
       if seq[i + 1] < seq[i]: # IndexError: list index out of range
           return False
       i = i + 1
    return True
#Function 2
def is_increasing2(seq):
    i = len(seq) - 1
    while i >= 0:
       if seq[i] < seq[i - 1]: # Error: check the seq[0]<seq[-1] here
           return False
       i = i - 1
    return True