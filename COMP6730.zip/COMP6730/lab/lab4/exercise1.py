#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 10:33:44 2018

@author: u5869920
"""

#Function 1
def integrate1(lower, upper, nterms):
    # divide the interval into nterms even-sized parts
    delta = (upper - lower) / nterms
    total = 0
    while lower+delta <= upper:
        # compute area from lower to lower + delta
        area = ((1/lower) + (1/(lower + delta))) * delta / 2
	# add to total area
        total = total + area
        lower = lower + delta
    return total
#Function 2
def integrate2(lower, upper, nterms):
    # divide the interval into nterms even-sized parts
    delta = (upper - lower) / nterms
    total = 0
    while lower+delta <= upper:
        # compute area from lower to lower + delta
        area = ((1/lower) + (1/(lower + delta))) * delta / 2
	# add to total area
        total = total + area
        #delta = (upper - lower) / nterms
        lower = lower + delta
    return total
