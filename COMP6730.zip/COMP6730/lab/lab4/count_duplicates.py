#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 15:51:11 2018

@author: u5869920
"""

def count_duplicates(seq):
    '''returns the number of duplicate elements.'''
    count=0
    for i in range(len(seq)):
        for j in range(i,len(seq)):
            if seq[i]==seq[j] and i!=j:
                count=count+1
    return count

def count_duplicate(seq):
    '''returns the number of duplicate elements-another way'''
    x=set(seq)
    return len(seq)-len(x)