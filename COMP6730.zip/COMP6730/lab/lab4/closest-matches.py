#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 15:29:58 2018

@author: u5869920
"""

def smallest_greater(seq,value):
    '''Return the smallest element in the sequence 
    that is greater than or equal to the given value.'''
    greater_list=[x for x in seq if x>=value]
    return min(greater_list)

def greatest_smaller(seq, value):
    '''Return the greatest element in the sequence 
    that is smaller than or equal to the given value.'''
    smaller_list=[x for x in seq if x<=value]
    return max(smaller_list)
    
def sorted_smallest_greater(seq,value):
    '''Return the smallest element in the sorted increasing 
    sequence that is greater than or equal to the given value.'''
    for i in range(len(seq)):
        if seq[i]>value:
            return seq[i]
        
def sorted_greatest_smaller(seq, value):
    '''Return the greatest element in the sorted increasing
    sequence that is smaller than or equal to the given value.'''
    for i in range(len(seq)):
        if seq[i]>value:
            return seq[i-1]