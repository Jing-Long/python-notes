#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 10:12:56 2018

@author: u5869920
"""
#my correct version
def any_one_is_sum(a,b,c):
    if a==b+c or b==a+c or c==a+b:
        return True
    else:
        return False

#wrong example codes
#Function 1
def any_one_is_sum1(a,b,c):
    sum_c=a+b
    sum_b=a+c
    sum_a=b+c
    if sum_c == a+b:
        if sum_b == c+a:
            if sum_a == b+c:
                return True
    else:
        return False
#Function 2
def any_one_is_sum2(a,b,c):
    if b + c == a:
        print(True)
    if c + b == a:
        print(True)
    else:
        print(False)
    return False

#Function 3
def any_one_is_sum3(a, b, c):
    if a+b==c and a+c==b:
        return True
    else:
        return False