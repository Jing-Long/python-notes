#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 17:03:25 2018

@author: u5869920
"""

def det(a1,a2,b1,b2):
    '''Return the determinant of matrix |a1 b1|
                                        |a2 b2|.'''
    return a1*b2-b1*a2

def solve2det(a1,b1,c1,a2,b2,c2):
    x=det(c1,c2,b1,b2)/det(a1,a2,b1,b2)
    y=det(a1,a2,c1,c2)/det(a1,a2,b1,b2)
    return x,y