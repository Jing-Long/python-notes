#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 10:54:24 2018

@author: u5869920
"""

import matplotlib.pyplot as plt
from numpy import linspace
import math

xs = linspace(-2.0, 4.0, 60)
ys = [math.sin(x) for x in xs]

plt.plot(xs, ys, linestyle="solid", color="blue")
plt.show()