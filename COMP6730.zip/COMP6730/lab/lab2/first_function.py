#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 10:31:07 2018

@author: u5869920
"""

def odd(n):
    return 2*n-1

print(odd(1))
print(odd(2))
print(odd(10))
