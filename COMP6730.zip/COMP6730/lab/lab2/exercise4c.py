#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 16:20:52 2018

@author: u5869920
"""

def solve1(a,b):
    '''Return the solution of ax=b.'''
    return b/a

def solve2(a1,b1,c1,a2,b2,c2):
    '''Return the solution of a1x+b1y=c1 and a2x+b2y=c2.'''
    r=a1/a2
    y=solve1(b1-r*b2,c1-r*c2)
    x=solve1(a1,c1-b1*y)
    return x,y

def solve3(a1,b1,c1,d1,a2,b2,c2,d2,a3,b3,c3,d3):
    '''Return the solution of 
       a1x+b1y+c1z=d1, a2x+b2y+c2z=d2 and a3x+b3y+c3z=d3.'''
    r=a1/a2
    s=a2/a3
    y,z=solve2(b1-r*b2,c1-r*c2,d1-r*d2,b2-s*b3,c2-s*c3,d2-s*d3)
    x=(d1-b1*y-c1*z)/a1
    return x,y,z