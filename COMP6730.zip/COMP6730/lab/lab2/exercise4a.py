#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 10:34:14 2018

@author: u5869920
"""
# n is an positive integer and it is the number of books
# this function is to test the total price of n books
def total_price(n):
    if n>0 and type(n)==int:
        book_price=24.95*(1-0.4)*n
        shipping_cost=3+(n-1)*0.75
        return book_price+shipping_cost
    else:
        print("invalid number of books:", n)
        
print(total_price(60))