#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 16:09:19 2018

@author: u5869920
"""
# calculate how many single adults at Canberra in year 2016

population=196037
families=50352
couple_with_children=22850
single_with_children=7243
couple_without_children=families-couple_with_children-single_with_children
children=1.8*(couple_with_children+single_with_children)

single_adults=population-children-2*(couple_with_children+couple_without_children)-single_with_children
print('There are',single_adults,'single adults at Canberra in year 2016')