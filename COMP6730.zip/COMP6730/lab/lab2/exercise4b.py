#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 11:16:47 2018

@author: u5869920
"""
distance_at_start= 21259598000 # km from the Sun
velocity=16.9995 # km/second
speed_of_light=299792.458 # km/s
def round_trip_communincation_time(n): # integer number of years after today
    '''Return round trip communication time to the Sun.'''
    time_since_start=n*365*24*60*60  # convert time to seconds
    distance=distance_at_start+ velocity* time_since_start
    return 2*distance/speed_of_light

AU=148.598e6 # km
def round_trip_communincation_time_to_Earth(n): # integer number of years after today
    '''Return round trip communication time to the Sun.'''
    time_since_start=n*365*24*60*60  # convert time to seconds
    distance=AU+distance_at_start+ velocity* time_since_start
    return 2*distance/speed_of_light


print("round trip communication time after 1 year:",round_trip_communincation_time(1),"seconds")
print("round trip communication time after 3 years:",round_trip_communincation_time(3),"seconds")
print("round trip communication time after 10 years:",round_trip_communincation_time(10),"seconds")
print("round trip communication time after 100 years:",round_trip_communincation_time(100),"seconds")
print("round trip communication time after 300 years:",round_trip_communincation_time(300),"seconds")