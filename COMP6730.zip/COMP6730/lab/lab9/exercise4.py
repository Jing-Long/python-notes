#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  3 18:54:16 2018

@author: u5869920
"""

def invert_dictionary(d):
    inverse_d={}
    for key, value in d.items():
        if value in inverse_d:
            print('Error: repeated value:',value,'for key:', key,'in the input dictionary.')
        else:
            inverse_d[value]=key
    return inverse_d

def invert_dict_set(d):
    inverse_d={}
    for key, value in d.items():
        keys=set()
        if value in inverse_d:
            inverse_d[value].add(key)
        else:
            keys.add(key)
            inverse_d[value]=keys
    return inverse_d