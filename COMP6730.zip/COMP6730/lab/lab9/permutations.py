#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  4 20:39:00 2018

@author: u5869920
"""
dic={ 'alice' : 'carol', 'bob' : 'bob', 'carol' : 'eve',
       'dave' : 'dave', 'eve' : 'alice' }
def dict_permutations(dic):
    if len(dic)==0:
        return [{}]
    else:
        all_permutations=[]
        one_permutation={}
        for key in dic.keys():
            for value in dic.values():
                one_permutation[key]=value
                all_permutations.append(one_permutation)   
    return all_permutations    

def closed_sets(perm):
    '''perm is a dictionary representing a permutation.'''
    sets = []
    # remaining_keys is the set of elements that are not yet in any closed
    # set in the list of sets
    remaining_keys = set(perm.keys())
    while len(remaining_keys) > 0:
        elem = remaining_keys.pop() # get an arbitrary element from set
        next_set = { elem }
        # find all elements in the same closed set as elem by following
        # the dictionary:
        while perm[elem] not in next_set:
            elem = perm[elem]
            next_set.add(elem)
            assert elem in perm, "not a permutation dictionary!"
        # add the new closed set to the list, and remove all elements
        # in it from the set of remaining keys:
        sets.append(next_set)
        remaining_keys = remaining_keys - next_set
    return sets