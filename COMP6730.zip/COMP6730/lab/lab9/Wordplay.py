#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  3 19:20:45 2018

@author: u5869920
"""
from operator import itemgetter

with open('wordlist.txt') as file:
    content=file.readlines()
    data=[x.strip() for x in content]   
    
def frequent_length(data):
    wordlen={word: len(word) for word in data}
    count={}
    for value in wordlen.values():
        if value in count:
            count[value]+=1
        else:
            count[value]=1
    sorted_count= sorted(count.items(), key=itemgetter(1),reverse=True)    
    return sorted_count

def three_consecutive_double_letters(data):
    for word in data:
       for i in range(len(word)-5):
           if word[i]==word[i+1] and word[i+2]==word[i+3] and word[i+4]==word[i+5]:
              return word
                  
def count_bi_grams(data):
    bi_grams={}
    for word in data:
        for i in range(len(word)-1):
            if word[i]+word[i+1] in bi_grams:
                bi_grams[word[i]+word[i+1]]+=1
            else: 
                bi_grams[word[i]+word[i+1]]=1
    sorted_bi_grams= sorted(bi_grams.items(), key=itemgetter(1),reverse=True)
    
    print(26**2-len(sorted_bi_grams),'out of',26**2,'bi-grams are not in this data.')
    
    words_with_repeated_bigrams={}
    for word in data:
        words_with_repeated_bigrams[word]=0
        for bi_gram in bi_grams.keys():
            if bi_gram in word:
                words_with_repeated_bigrams[word]+=1
    sorted_words_with_repeated_bigrams=sorted(words_with_repeated_bigrams.items(), key=itemgetter(1),reverse=True)      
    count_words_with_repeated_bigrams=len([count for count in words_with_repeated_bigrams.values() if count>1])
    print('There are',count_words_with_repeated_bigrams,'words in this data have repeated bi-grams.')
    print(sorted_words_with_repeated_bigrams[0][0],\
          'has the highest number of repetitions, it is',\
         sorted_words_with_repeated_bigrams[0][1])
    return sorted_bi_grams[:10]