#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  3 21:15:11 2018

@author: u5869920
"""
import string
from operator import itemgetter
from urllib.request import urlopen

fileobj1 = urlopen("http://www.gutenberg.org/ebooks/42671.txt.utf-8")
fileobj2 = urlopen("http://www.gutenberg.org/ebooks/62.txt.utf-8")
wordlist = ['test', 'your', 'function', 'with', 'a', 'diverse',
 'range', 'of', 'examples', 'your', 'tests', 'should', 'cover',
 'all', 'cases', 'for', 'example', 'test', 'words', 'beginning',
 'with', 'a', 'vowel', 'and', 'word', 'beginning', 'with', 'a',
 'consonant', 'pay', 'particular', 'attention', 'to', 'edge',
 'cases', 'for', 'example', 'what', 'happens', 'if', 'the',
 'word', 'consists', 'of', 'just', 'one', 'vowel', 'like',
 'a', 'what', 'happens', 'if', 'the', 'string', 'is', 'empty']

def words_in_book(fileobj):
    data=[]
    exclude = set(string.punctuation)
    for byteseq in fileobj:
        line = byteseq.decode()
        # process line of text
        line= ''.join(char for char in line if char not in exclude)
        line=line.strip('\n\r\ufeff')
        wordslist=line.split(' ')
        wordslist=list(filter(None,wordslist))# remove ''.
        data.extend(wordslist)
    fileobj.close()
    return data



def word_frequency(data):
    word_count={}
    for word in data:
        if word.lower() in word_count:
            word_count[word.lower()]+=1
        else:
            word_count[word.lower()]=1
    sorted_word_count= sorted(word_count.items(), key=itemgetter(1),reverse=True)
    print('There are',len(sorted_word_count),'different words are used in this book.')
    print('The most frequent 10 words are:',sorted_word_count[:10])
    return sorted_word_count

def compare_diff_words(filedict1,filedict2):  
    count=0
    for word in filedict1:
        if word in filedict2:
            count+=1
    print('There are',len(filedict1),'and',len(filedict2),'words in these two files,',
          count,'of them them are the same.')
    
def not_in_wordlist(filedict,wordlist):
    for word in set(wordlist):
        if word not in (item[0] for item in filedict):
            print(word,'is not in this book.')