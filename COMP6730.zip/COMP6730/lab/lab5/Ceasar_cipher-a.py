
def Ceasar_cipher(string,shift):
    cipher=''
    for char in string:
        if ord('A')<=ord(char)<=ord('A')+26:
	        if ord(char)+shift%26>ord('Z'):
 	            cipher=cipher+chr(ord(char)+shift%26-26)
	        else:
		        cipher=cipher+chr(ord(char)+shift%26)
        elif ord('a')<=ord(char)<=ord('a')+26: 
	        if ord(char)+shift%26>ord('z'):
 	            cipher=cipher+chr(ord(char)+shift%26-26)
	        else:
		        cipher=cipher+chr(ord(char)+shift%26)
        else:
	         cipher=cipher+char
    return cipher


