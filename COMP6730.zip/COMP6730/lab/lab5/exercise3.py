# -*- coding: utf-8 -*-
"""
Created on Mon Aug 27 22:55:30 2018

@author: Administrator
"""
# (a)
def count_negative(array):
    count=0
    for number in array:
        if number <0:
            count=count+1
    return count

# (b)    
def count_capitals(string):
    count=0
    for character in string:
        if ord('A')<=ord(character)<=ord('Z'):
            count=count+1
    return count

# (c)
def fun(seq):
    if condition:
        return True
def count_property(seq,fun(seq)):
    count=0
    if fun(seq)==True:
       count=count+1
    return count

# (d)
# while is more suitable for function: is_increasing(seq)
# for is more suitable for function:  most_average()

