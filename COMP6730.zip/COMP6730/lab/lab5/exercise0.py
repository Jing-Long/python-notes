# -*- coding: utf-8 -*-
"""
Created on Mon Aug 27 22:16:18 2018

@author: Administrator
"""

x1="The possessive form of 'it' is 'its'\n"+'-"it\'s" is an abbreviation of "it is".'
x2='''The possessive form of 'it' is 'its'
-"it's" is an abbrevation of "it is".'''

y1="A ''' is three ' but two ' do not make a \"."
y2='''A \''' is three ' but two ' do not make a ".'''

print(x1,x2,y1,y2)