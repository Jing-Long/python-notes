#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 10:17:11 2018

@author: u5869920
"""

def pig_latin(string):
    '''Translate an English word into Pig Latin.'''
    vowels='aeiou'
    lower_string=string.lower()
    pig_latin_str=''
    if lower_string[0] in vowels:
        pig_latin_str=lower_string+'yay'
    else:
        pig_latin_str=lower_string[1:]+lower_string[0]
        if pig_latin_str[0] in vowels:
            pig_latin_str=pig_latin_str+'ay'
        else:
            pig_latin_str=pig_latin(pig_latin_str)
    return pig_latin_str
        