# 1.
def Ceasar_decipher1(string):   
    for shift in range(26):
        decipher=''
        for char in string[:len(string)]:
            if ord('A')<=ord(char)<=ord('A')+26:
               if ord(char)-shift<ord('A'):
 	              decipher=decipher+chr(ord(char)-shift+26)
               else:
                  decipher=decipher+chr(ord(char)-shift)
            elif ord('a')<=ord(char)<=ord('a')+26: 
               if ord(char)-shift<ord('a'):
 	              decipher=decipher+chr(ord(char)-shift+26)
               else:
                  decipher=decipher+chr(ord(char)-shift)
            else:
                 decipher=decipher+char
        print(shift, decipher)

# 2.
commons=['the','and','for','are','but','not','you','all','any','can',
	 'her','was','one','our','out','day','get','has','him','his',
 	 'how','man','new','now','old','see','two','way','who','boy',
	 'did','its','let','put','say','she','too','use','dad','mom']

def Ceasar_decipher2(string):
    highest_number_count=0
    correct_shift=0
    for shift in range(26):
        decipher=''
        count=0
        for char in string[:len(string)]:
            if ord('A')<=ord(char)<=ord('A')+26:
                if ord(char)-shift<ord('A'):
 	               decipher=decipher+chr(ord(char)-shift+26)
                else:
                   decipher=decipher+chr(ord(char)-shift)
            elif ord('a')<=ord(char)<=ord('a')+26: 
                if ord(char)-shift%26<ord('a'):
                   decipher=decipher+chr(ord(char)-shift+26)
                else:
                   decipher=decipher+chr(ord(char)-shift)
            else:
                decipher=decipher+char
        for word in commons:
            if word in decipher.lower():
                count=count+1
        if count> highest_number_count:
            correct_shift=shift
            highest_number_count=count
        print(shift, count, correct_shift, decipher)
    return "the correct shift is", correct_shift

#3. Not a good one. 'e' is not always the most frequent letter in a sentence. 
def Ceasar_decipher3(strings):
    most_frequent=''
    most_count=0
    decipher=''
    string=strings.lower()
    for char in string:
        if string.count(char)>most_count:
	   #print string.count(char), char
           most_count=string.count(char)
           most_frequent=char
    shift=ord(most_frequent)-ord('e')
    #print most_frequent
    for char in string[:len(string)]:
            if ord('A')<=ord(char)<=ord('A')+26:
                if ord(char)-shift%26<ord('A'):
                    decipher=decipher+chr(ord(char)-shift%26+26)
                else:
                    decipher=decipher+chr(ord(char)-shift%26)
            elif ord('a')<=ord(char)<=ord('a')+26: 
                if ord(char)-shift%26<ord('a'):
                    decipher=decipher+chr(ord(char)-shift%26+26)
                else:
                    decipher=decipher+chr(ord(char)-shift%26)
            else:
                 decipher=decipher+char
    return decipher

# test
a='''Awnhu pk neoa wjz awnhu pk xaz 
Iwgao w iwj dawhpdu, xqp okyewhhu zawz'''
b='"Jcstghipcsxcv xh iwpi etctigpixcv fjpaxin du zcdlatsvt iwpi vgdlh ugdb iwtdgn, egprixrt, rdckxrixdc, phhtgixdc, tggdg pcs wjbxaxipixdc." (Gjat 7: Jht p rdadc puitg pc xcstetcstci rapjht id xcigdsjrt p axhi du epgixrjapgh, pc peedhxixkt, pc pbeaxuxrpixdc dg pc xaajhigpixkt fjdipixdc. Ugdb Higjcz & Lwxit, "Iwt Tatbtcih du Hinat".)'
c="Cywo cmsoxdscdc gybu cy rkbn drobo sc xy dswo vopd pyb cobsyec drsxusxq. (kddbsledon dy Pbkxmsc Mbsmu)"

